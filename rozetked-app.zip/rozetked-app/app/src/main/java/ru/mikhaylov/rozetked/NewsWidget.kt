package ru.mikhaylov.rozetked

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Xml
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

data class NewsItem(val title: String, val link: String, val time: Long)

/**
 * Виджет «Новости Розеткед»: список свежих новостей из RSS сайта.
 * Обновляется сам примерно раз в 30 минут (чаще Android не даёт) и по кнопке ↻.
 * Нажатие на новость открывает её в приложении.
 */
class NewsWidget : AppWidgetProvider() {

    companion object {
        private const val RSS = "https://rozetked.me/rss.xml"
        private const val PREFS = "news_widget"
        private const val KEY_ITEMS = "items"
        private const val MAX_ITEMS = 20
        const val ACTION_REFRESH = "ru.mikhaylov.rozetked.WIDGET_REFRESH"
        private val io = Executors.newSingleThreadExecutor()

        fun cached(context: Context): List<NewsItem> = runCatching {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, null)
                ?: return emptyList()
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                NewsItem(o.getString("t"), o.getString("l"), o.optLong("d"))
            }
        }.getOrDefault(emptyList())

        private fun save(context: Context, items: List<NewsItem>) {
            val arr = JSONArray()
            items.forEach { arr.put(JSONObject().put("t", it.title).put("l", it.link).put("d", it.time)) }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, arr.toString()).apply()
        }

        /** Время новости: «14:38» для сегодняшних, «28 окт.» для остальных. */
        fun formatTime(t: Long): String {
            if (t <= 0L) return ""
            val now = Calendar.getInstance()
            val c = Calendar.getInstance().apply { timeInMillis = t }
            val sameDay = now.get(Calendar.YEAR) == c.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
            val pattern = if (sameDay) "HH:mm" else "d MMM, HH:mm"
            return SimpleDateFormat(pattern, Locale("ru")).format(c.time)
        }

        private fun fetch(): List<NewsItem> {
            val conn = URL(RSS).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "RozetkedApp/1.0 (Android)")
            try {
                conn.inputStream.use { input ->
                    val p = Xml.newPullParser()
                    p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                    p.setInput(input, null)
                    val out = ArrayList<NewsItem>()
                    var inItem = false
                    var title = ""
                    var link = ""
                    var date = ""
                    var tag = ""
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT && out.size < MAX_ITEMS) {
                        when (ev) {
                            XmlPullParser.START_TAG -> {
                                tag = p.name
                                if (tag == "item") {
                                    inItem = true; title = ""; link = ""; date = ""
                                }
                            }
                            XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (inItem) {
                                val txt = p.text ?: ""
                                when (tag) {
                                    "title" -> title += txt
                                    "link" -> link += txt
                                    "pubDate" -> date += txt
                                }
                            }
                            XmlPullParser.END_TAG -> {
                                if (p.name == "item") {
                                    inItem = false
                                    val t = title.trim()
                                    val l = link.trim()
                                    if (t.isNotEmpty() && l.startsWith("http")) out.add(NewsItem(t, l, parseDate(date.trim())))
                                }
                                tag = ""
                            }
                        }
                        ev = p.next()
                    }
                    return out
                }
            } finally {
                conn.disconnect()
            }
        }

        private fun parseDate(s: String): Long = runCatching {
            SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).parse(s)!!.time
        }.getOrDefault(0L)

        /** Перерисовать все виджеты (данные берутся из кэша). */
        fun render(context: Context, loading: Boolean = false) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, NewsWidget::class.java))
            if (ids.isEmpty()) return
            for (id in ids) {
                val rv = RemoteViews(context.packageName, R.layout.widget_news)

                // Список: данные отдаёт NewsWidgetService
                val svc = Intent(context, NewsWidgetService::class.java).apply {
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
                }
                @Suppress("DEPRECATION")
                rv.setRemoteAdapter(R.id.widgetList, svc)
                rv.setEmptyView(R.id.widgetList, R.id.widgetEmpty)
                rv.setTextViewText(
                    R.id.widgetEmpty,
                    context.getString(if (loading) R.string.widget_loading else R.string.widget_empty)
                )

                // Нажатие на новость — открыть её в приложении
                val open = Intent(context, MainActivity::class.java).apply {
                    action = Intent.ACTION_VIEW
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                rv.setPendingIntentTemplate(
                    R.id.widgetList,
                    PendingIntent.getActivity(context, 1, open,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                )

                // Заголовок открывает главную
                val home = Intent(context, MainActivity::class.java).apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                rv.setOnClickPendingIntent(R.id.widgetTitle,
                    PendingIntent.getActivity(context, 2, home,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

                // Кнопка ↻
                val refresh = Intent(context, NewsWidget::class.java).setAction(ACTION_REFRESH)
                rv.setOnClickPendingIntent(R.id.widgetRefresh,
                    PendingIntent.getBroadcast(context, 3, refresh,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                rv.setViewVisibility(R.id.widgetRefresh, if (loading) View.INVISIBLE else View.VISIBLE)

                mgr.updateAppWidget(id, rv)
            }
            @Suppress("DEPRECATION")
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.widgetList)
        }

        /** Скачать RSS в фоне, сохранить и перерисовать. */
        fun refresh(context: Context, done: (() -> Unit)? = null) {
            val app = context.applicationContext
            render(app, loading = true)
            io.execute {
                runCatching { fetch() }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { save(app, it) }
                render(app, loading = false)
                done?.invoke()
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        refresh(context) { pending.finish() }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val pending = goAsync()
            refresh(context) { pending.finish() }
        }
    }
}
