package ru.mikhaylov.rozetked

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/** Отдаёт строки списка виджета из кэша новостей. */
class NewsWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(val context: Context) : RemoteViewsService.RemoteViewsFactory {
        private var items: List<NewsItem> = emptyList()

        override fun onCreate() {
            items = NewsWidget.cached(context)
        }

        override fun onDataSetChanged() {
            items = NewsWidget.cached(context)
        }

        override fun onDestroy() {
            items = emptyList()
        }

        override fun getCount(): Int = items.size

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget_item)
            val it = items.getOrNull(position) ?: return rv
            rv.setTextViewText(R.id.itemTitle, it.title)
            rv.setTextViewText(R.id.itemTime, NewsWidget.formatTime(it.time))
            rv.setOnClickFillInIntent(R.id.item, Intent().setData(Uri.parse(it.link)))
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = items.getOrNull(position)?.link?.hashCode()?.toLong() ?: position.toLong()
        override fun hasStableIds(): Boolean = true
    }
}
