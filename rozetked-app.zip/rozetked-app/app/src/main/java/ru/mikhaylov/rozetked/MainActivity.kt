package ru.mikhaylov.rozetked

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.View
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewPropertyAnimator
import android.view.animation.PathInterpolator
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.BackEventCompat
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.drawToBitmap
import androidx.core.view.updateLayoutParams
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONArray
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        private const val HOME = "https://rozetked.me/"
        private const val BLANK = "about:blank"
        private const val SHIFT_DP = 56f          // сдвиг при переходе внутри экрана (shared axis)
        private const val PARALLAX_DP = 72f       // насколько лента уезжает влево под статьёй
        private const val FEED_DIM = 0.28f        // затемнение ленты под статьёй
        private const val GESTURE_DIM = 0.32f
        private const val MAX_SNAPSHOTS = 8
        private const val DRAG_UNDECIDED = 0
        private const val DRAG_ACTIVE = 1
        private const val DRAG_REJECTED = 2
        private const val TEXT_ZOOM_FACTOR = 0.9f // шрифт на 10% мельче
        private val ARTICLE = Regex("^/(index\\.php/)?(news|articles|reviews|posts)/\\d+")
        private val ARTICLE_ID = Regex("/(?:news|articles|reviews|posts)/(\\d+)")

        /**
         * Встраивается в каждую страницу:
         *  • прячет подвал сайта, «Подписывайтесь на Rozetked…» и «Поделитесь публикацией…»
         *    (текст сравнивается без учёта неразрывных пробелов и регистра);
         *  • сообщает приложению цвета шапки и низа страницы — сразу, в том числе при смене темы на сайте.
         */
        private const val PAGE_JS = """(function(){
if(window.__rzk)return;window.__rzk=1;
function N(s){return (s||'').replace(/[\s  ]+/g,' ').trim().toLowerCase();}
function addStyle(){if(document.getElementById('rzk-app'))return;var s=document.createElement('style');s.id='rzk-app';
s.textContent='html{-webkit-tap-highlight-color:transparent}.rzk-hide{display:none!important}';
(document.head||document.documentElement).appendChild(s);}
function len(e){return N(e.textContent).length;}
function holdsContent(p){return !!p.querySelector('article,main,h1,h2,[itemprop=articleBody]');}
function climb(el,limit){while(el.parentElement&&el.parentElement!==document.body&&el.parentElement!==document.documentElement){var p=el.parentElement;if(p.tagName==='ARTICLE'||p.tagName==='MAIN'||holdsContent(p)||len(p)>limit(el))break;el=p;}return el;}
function locate(first,phrase){var res=[];var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);var n;
while((n=w.nextNode())){if(N(n.nodeValue).indexOf(first)<0)continue;var e=n.parentElement,k=0;
while(e&&k<6&&N(e.textContent).indexOf(phrase)<0){e=e.parentElement;k++;}
if(e&&e!==document.body&&e!==document.documentElement&&!e.closest('.rzk-hide'))res.push(e);}return res;}
function hide(first,phrase,limit,useFooter){if(!document.body)return;locate(first,phrase).forEach(function(el){if(el.closest('.rzk-hide'))return;
var f=useFooter&&el.closest('footer');if(f&&!holdsContent(f)){f.classList.add('rzk-hide');return;}
climb(el,limit).classList.add('rzk-hide');});}
function clean(){addStyle();
hide('пользовательское','пользовательское соглашение',function(){return 300;},true);
hide('подписывайтесь','подписывайтесь на rozetked',function(e){return len(e)+10;});
hide('поделитесь','поделитесь публикацией',function(e){return len(e)+10;});}
function bg(e){while(e&&e.nodeType===1){var c=getComputedStyle(e).backgroundColor;if(c&&c!=='transparent'&&!/rgba\([^)]*,\s*0\)$/.test(c))return c;e=e.parentElement;}return '';}
function report(){try{if(!document.body)return;var w=innerWidth/2;var t=document.elementFromPoint(w,1),b=document.elementFromPoint(w,innerHeight-1);
var d=bg(document.body)||bg(document.documentElement);var s=[bg(t)||d,bg(b)||d,d].join('|');
if(s!==window.__rzkLast){window.__rzkLast=s;if(window.RzkApp)RzkApp.colors(s);}}catch(e){}}
window.__rzkReport=function(){window.__rzkLast='';report();};
var rt;function soon(){clearTimeout(rt);rt=setTimeout(report,60);setTimeout(report,450);}
addEventListener('scroll',function(){clearTimeout(rt);rt=setTimeout(report,120);},{passive:true});
addEventListener('click',soon,true);
try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',soon);}catch(e){}
var opts={attributes:true,attributeFilter:['class','style','data-theme','data-mode','data-color-scheme']};
var ao=new MutationObserver(soon);function watch(){ao.observe(document.documentElement,opts);if(document.body)ao.observe(document.body,opts);}
function all(){clean();watch();soon();}
all();
document.addEventListener('DOMContentLoaded',all);addEventListener('load',all);
new MutationObserver(function(){clearTimeout(window.__rzkT);window.__rzkT=setTimeout(clean,150);})
.observe(document.documentElement,{childList:true,subtree:true});
})()"""

        /** Список статей в ленте по порядку — для свайпов. */
        private const val LIST_JS = """(function(){var re=/^\/(index\.php\/)?(news|articles|reviews|posts)\/\d+/;var seen={},out=[];
var as=document.querySelectorAll('a[href]');for(var i=0;i<as.length;i++){var u;try{u=new URL(as[i].href,location.href);}catch(e){continue;}
if(!/(^|\.)rozetked\.me$/.test(u.hostname))continue;if(!re.test(u.pathname))continue;
var m=u.pathname.match(/\/(?:news|articles|reviews|posts)\/(\d+)/);var id=m?m[1]:u.pathname;if(seen[id])continue;seen[id]=1;
out.push(u.origin+u.pathname);}return JSON.stringify(out);})()"""

        /** Нельзя листать, если страница увеличена щипком или под пальцем карусель/широкая таблица. */
        private const val HSCROLL_JS = """(function(px,py){if(window.visualViewport&&visualViewport.scale>1.05)return true;
var r=window.devicePixelRatio||1;var e=document.elementFromPoint(px/r,py/r);
while(e&&e!==document.body&&e!==document.documentElement){var s=getComputedStyle(e);
if((s.overflowX==='auto'||s.overflowX==='scroll')&&e.scrollWidth>e.clientWidth+4&&!e.querySelector('h1'))return true;
var c=typeof e.className==='string'?e.className:'';if(/swiper|slick|carousel|splide|glide|owl-/i.test(c))return true;
e=e.parentElement;}return false;})"""

    }

    /** Один «экран»: лента или статья. У каждого своя WebView, история и снимки. */
    private inner class Layer(val name: String, val card: FrameLayout, val web: WebView) {
        val snapshots = HashMap<Int, Bitmap>()
        var historyIndex = 0
        var failedUrl: String? = null
        var clearHistoryOnCommit = false
        var colors: Triple<Int, Int, Int>? = null
    }

    private enum class Dir { FORWARD, BACK }
    private enum class Style { SHIFT, PAGE }
    private enum class Gesture { NONE, IN_LAYER, CLOSE_ARTICLE }

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var overlay: ImageView
    private lateinit var underlay: ImageView
    private lateinit var underlayScrim: View
    private lateinit var errorView: View
    private lateinit var errorCode: TextView
    private lateinit var statusScrim: View
    private lateinit var navScrim: View
    private lateinit var fab: FloatingActionButton
    private lateinit var fullscreen: FrameLayout

    private lateinit var feed: Layer
    private lateinit var article: Layer
    private var articleOpen = false
    private val active: Layer get() = if (articleOpen) article else feed

    private val main = Handler(Looper.getMainLooper())
    private val chrome = Chrome()

    // Переход внутри экрана
    private var transition: Dir? = null
    private var transitionStyle = Style.SHIFT
    private var transitionLayer: Layer? = null
    private var transitionFromUrl: String? = null
    private var capturing = false

    // Жест «назад»
    private var gesture = Gesture.NONE
    private var gestureLayer: Layer? = null
    private var gestureDir = 1f
    private var gestureStartY = 0f
    private var pendingBack: Layer? = null
    private var pendingBackFromUrl: String? = null
    private val radii = HashMap<View, Float>()

    // Свайпы между статьями
    private var articleList: List<String> = emptyList()
    private var articleIndex = -1
    private var horizontalBlocked = false
    private var dragState = DRAG_UNDECIDED
    private var dragX0 = 0f
    private var dragY0 = 0f
    private var dragSnapshot: Bitmap? = null
    private var velocity: VelocityTracker? = null
    private var opening = false

    private var errorDetail = ""
    private var firstContentShown = false
    private var websAlive = true
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private var topColor = 0
    private var bottomColor = 0
    private val startTime = SystemClock.uptimeMillis()

    // Кривые Material 3
    private val emphasizedDecel = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    private val emphasizedAccel = PathInterpolator(0.3f, 0f, 0.8f, 0.15f)
    private val standard = PathInterpolator(0.2f, 0f, 0f, 1f)

    private val transitionTimeout = Runnable { finishTransition() }
    private val gestureTimeout = Runnable { finishGestureBack() }
    private var hrefFrom: Layer? = null
    private val hrefHandler = Handler(Looper.getMainLooper()) { msg ->
        val from = hrefFrom
        msg.data?.getString("url")?.takeIf { it.isNotBlank() }?.let { if (from != null) showLinkSheet(it, from) }
        true
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackStarted(backEvent: BackEventCompat) = startBackGesture(backEvent)
        override fun handleOnBackProgressed(backEvent: BackEventCompat) = progressBackGesture(backEvent)
        override fun handleOnBackCancelled() = cancelBackGesture()
        override fun handleOnBackPressed() = onBack()
    }

    // ───────────────────────────── Жизненный цикл ─────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        swipe = findViewById(R.id.swipe)
        overlay = findViewById(R.id.overlay)
        underlay = findViewById(R.id.underlay)
        underlayScrim = findViewById(R.id.underlayScrim)
        errorView = findViewById(R.id.errorView)
        errorCode = findViewById(R.id.errorCode)
        statusScrim = findViewById(R.id.statusScrim)
        navScrim = findViewById(R.id.navScrim)
        fab = findViewById(R.id.fabShare)
        fullscreen = findViewById(R.id.fullscreen)
        feed = Layer("feed", findViewById(R.id.feedCard), findViewById(R.id.feedWeb))
        article = Layer("article", findViewById(R.id.articleCard), findViewById(R.id.articleWeb))

        topColor = ContextCompat.getColor(this, R.color.page_bg)
        bottomColor = topColor

        val restoring = savedInstanceState != null
        splash.setKeepOnScreenCondition {
            !restoring && !firstContentShown && SystemClock.uptimeMillis() - startTime < 2500
        }
        splash.setOnExitAnimationListener { provider ->
            runCatching {
                provider.iconView.animate().scaleX(1.4f).scaleY(1.4f).alpha(0f)
                    .setDuration(320).setInterpolator(emphasizedAccel).start()
            }
            provider.view.animate().alpha(0f).setStartDelay(60).setDuration(300)
                .setInterpolator(standard).withEndAction { provider.remove() }.start()
        }

        setupInsets()
        setupCard(feed.card)
        setupCard(article.card)
        setupWeb(feed)
        setupWeb(article)
        setupFeedRefresh()
        setupArticleSwipes()

        findViewById<MaterialButton>(R.id.retry).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val l = active
            l.failedUrl = null
            hideError()
            if (l.web.url.isNullOrEmpty() || l.web.url == BLANK) {
                l.web.loadUrl(if (l === feed) HOME else (articleList.getOrNull(articleIndex) ?: HOME))
            } else {
                l.web.reload()
            }
        }
        fab.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            share(article.web.url ?: HOME, article.web.title)
        }

        onBackPressedDispatcher.addCallback(this, backCallback)

        val restored = savedInstanceState?.getBundle("feed")?.let { feed.web.restoreState(it) } != null
        if (!restored) {
            content.alpha = 0f
            val data = intent?.data
            if (data != null && isInternal(data) && !isArticle(data.toString())) {
                feed.web.loadUrl(data.toString())
            } else {
                feed.web.loadUrl(HOME)
                if (data != null && isInternal(data)) showArticle(data.toString())
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.data?.toString() ?: return
        if (!isInternal(Uri.parse(url))) return
        when {
            isArticle(url) && articleOpen -> navigateForward(article, url)
            isArticle(url) -> {
                articleList = emptyList(); articleIndex = -1
                showArticle(url)
            }
            else -> {
                if (articleOpen) closeArticle()
                navigateForward(feed, url)
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (!websAlive) return
        val b = Bundle()
        runCatching { feed.web.saveState(b) }
        outState.putBundle("feed", b)
    }

    override fun onResume() {
        super.onResume()
        if (websAlive) {
            feed.web.onResume(); article.web.onResume()
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        if (websAlive) {
            feed.web.onPause(); article.web.onPause()
        }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        destroyWebs()
        super.onDestroy()
    }

    private fun destroyWebs() {
        if (!websAlive) return
        websAlive = false
        for (l in listOf(feed, article)) {
            (l.web.parent as? ViewGroup)?.removeView(l.web)
            runCatching { l.web.destroy() }
        }
    }

    // ───────────────────────────── Настройка ─────────────────────────────

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottom = max(bars.bottom, ime.bottom)
            content.setPadding(bars.left, bars.top, bars.right, bottom)
            statusScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.top }
            navScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.bottom }
            fab.updateLayoutParams<FrameLayout.LayoutParams> {
                bottomMargin = dp(20) + bottom
                rightMargin = dp(20) + bars.right
            }
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupCard(card: View) {
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radii[view] ?: 0f)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(layer: Layer) {
        val web = layer.web
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = max(50, (textZoom * TEXT_ZOOM_FACTOR).roundToInt())
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.setBackgroundColor(bottomColor)
        web.addJavascriptInterface(ColorBridge(layer), "RzkApp")
        web.webViewClient = Client(layer)
        web.webChromeClient = chrome
        web.setDownloadListener { url, _, _, _, _ -> openExternal(url, forceBrowser = true) }
        web.setOnLongClickListener { onWebLongPress(layer) }
        if (layer === article) {
            web.setOnScrollChangeListener { _, _, y, _, oldY -> onArticleScroll(y, oldY) }
        }
    }

    private fun setupFeedRefresh() {
        swipe.setColorSchemeColors(MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary))
        swipe.setProgressBackgroundColorSchemeColor(
            MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        )
        swipe.setOnChildScrollUpCallback { _, _ -> feed.web.scrollY > 0 }
        swipe.setOnRefreshListener {
            feed.failedUrl = null
            feed.web.reload()
        }
    }

    // ───────────────────────────── WebView ─────────────────────────────

    private inner class Client(val layer: Layer) : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (!request.isForMainFrame) return false
            val uri = request.url
            val url = uri.toString()
            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") {
                if (url == BLANK) return false
                openExternal(url); return true
            }
            if (!isInternal(uri)) {
                openExternal(url); return true
            }
            if (capturing || opening) return true            // двойной тап во время перехода
            layer.failedUrl = null
            if (request.isRedirect || transition != null || pendingBack != null) return false
            if (isSameDocument(layer, url)) return false
            if (layer === feed && isArticle(url)) {
                openArticleFromFeed(url)
            } else {
                navigateForward(layer, url)
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            if (url == BLANK) return
            injectPageJs(view)
        }

        override fun onPageCommitVisible(view: WebView, url: String?) {
            if (url == BLANK) return
            injectPageJs(view)
            onContentVisible(layer, url)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (url == BLANK) return
            if (layer === feed) swipe.isRefreshing = false
            injectPageJs(view)
            onContentVisible(layer, url)
            if (layer === active) main.postDelayed({ sampleColors() }, 150)
            updateBackCallback()
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            layer.historyIndex = view.copyBackForwardList().currentIndex
            if (layer === article && url != null) {
                val id = articleId(url)
                val idx = articleList.indexOfFirst { articleId(it) == id }
                if (idx >= 0) articleIndex = idx
                refreshFab()
            }
            updateBackCallback()
        }


        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val desc = error.description?.toString().orEmpty()
            if (desc.contains("ERR_ABORTED")) return
            layer.failedUrl = request.url.toString()
            errorDetail = "${error.errorCode} · $desc"
            if (layer === active) showError()
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            destroyWebs()
            recreate()
            return true
        }
    }

    private inner class Chrome : WebChromeClient() {


        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden(); return
            }
            customView = view
            customViewCallback = callback
            fullscreen.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fullscreen.alpha = 0f
            fullscreen.visibility = View.VISIBLE
            fullscreen.anim().alpha(1f).setDuration(200).setInterpolator(standard).start()
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            updateBackCallback()
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            customView = null
            fullscreen.removeView(v)
            fullscreen.visibility = View.GONE
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
            WindowInsetsControllerCompat(window, window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
            updateBackCallback()
        }
    }

    private fun onContentVisible(layer: Layer, url: String?) {
        if (!firstContentShown) {
            firstContentShown = true
            // Первое появление: лёгкий подъём и проявление
            content.alpha = 0f
            content.translationY = dp(24f)
            content.anim().alpha(1f).translationY(0f).setDuration(480)
                .setInterpolator(emphasizedDecel).start()
        }
        if (layer.clearHistoryOnCommit) {
            layer.clearHistoryOnCommit = false
            layer.web.clearHistory()
            layer.historyIndex = 0
            updateBackCallback()
        }
        if (layer === article && article.web.alpha < 1f && transition == null) {
            article.web.anim().alpha(1f).setDuration(220).setInterpolator(standard).start()
        }
        if (layer.failedUrl != null && url == layer.failedUrl) {
            if (layer === active) showError()
        } else {
            layer.failedUrl = null
            if (layer === active) hideError()
        }
        if (transition != null && transitionLayer === layer && url != transitionFromUrl) finishTransition()
        if (pendingBack === layer && url != pendingBackFromUrl) finishGestureBack()
    }

    private fun injectPageJs(web: WebView) {
        web.evaluateJavascript(PAGE_JS, null)
    }

    // ───────────────────────────── Статья поверх ленты ─────────────────────────────

    private fun openArticleFromFeed(url: String) {
        if (opening) return
        opening = true
        feed.web.evaluateJavascript(LIST_JS) { r ->
            val list = runCatching {
                val arr = JSONArray(JSONTokener(r).nextValue() as String)
                (0 until arr.length()).map { arr.getString(it) }
            }.getOrDefault(emptyList())
            val id = articleId(url)
            articleList = list
            articleIndex = list.indexOfFirst { articleId(it) == id }
            opening = false
            showArticle(url)
        }
    }

    /** Экран статьи выезжает справа, лента чуть уходит влево и темнеет. */
    private fun showArticle(url: String) {
        val card = article.card
        val w = (if (content.width > 0) content.width else resources.displayMetrics.widthPixels).toFloat()
        articleOpen = true
        article.failedUrl = null
        article.snapshots.clear()
        article.clearHistoryOnCommit = true
        article.web.alpha = 0f
        article.web.loadUrl(url)

        card.animate().cancel()
        resetCard(card)
        card.translationX = w
        card.visibility = View.VISIBLE
        card.anim().translationX(0f).setDuration(380).setInterpolator(emphasizedDecel).start()

        underlay.visibility = View.GONE
        underlayScrim.visibility = View.VISIBLE
        underlayScrim.anim().alpha(FEED_DIM).setDuration(380).setInterpolator(emphasizedDecel).start()
        feed.card.anim().translationX(-dp(PARALLAX_DP)).setDuration(380).setInterpolator(emphasizedDecel).start()

        refreshError()
        refreshFab()
        updateBackCallback()
        sampleColors()
    }

    /** Статья уезжает вправо, под ней — та же лента на том же месте. */
    private fun closeArticle(fromGesture: Boolean = false) {
        if (!articleOpen) return
        if (transitionLayer === article) finishTransition()
        articleOpen = false
        val card = article.card
        val dur = if (fromGesture) 240L else 320L
        if (fromGesture) {
            card.anim()
                .alpha(0f).scaleX(0.86f).scaleY(0.86f)
                .translationX(card.translationX + gestureDir * dp(48f))
                .setDuration(200).setInterpolator(emphasizedAccel)
                .withEndAction { hideArticleCard() }.start()
        } else {
            card.anim().translationX(card.width.toFloat()).setDuration(dur).setInterpolator(standard)
                .withEndAction { hideArticleCard() }.start()
        }
        feed.card.anim().translationX(0f).setDuration(dur).setInterpolator(standard).start()
        underlayScrim.anim().alpha(0f).setDuration(dur).setInterpolator(standard)
            .withEndAction { underlayScrim.visibility = View.GONE }.start()
        refreshError()
        refreshFab()
        updateBackCallback()
        main.postDelayed({ sampleColors() }, 60)
    }

    private fun hideArticleCard() {
        val card = article.card
        card.visibility = View.GONE
        resetCard(card)
        article.web.stopLoading()
        article.web.loadUrl(BLANK)
        article.snapshots.clear()
    }

    // ───────────────────────────── Свайпы между статьями ─────────────────────────────

    /**
     * Статья тянется за пальцем по горизонтали; отпустили дальше четверти экрана
     * или быстрым взмахом — выезжает следующая (влево) или предыдущая (вправо).
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupArticleSwipes() {
        val cfg = ViewConfiguration.get(this)
        val slop = cfg.scaledTouchSlop.toFloat()
        val minFling = cfg.scaledMinimumFlingVelocity * 4f
        article.web.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragX0 = ev.x
                    dragY0 = ev.y
                    dragState = DRAG_UNDECIDED
                    dragSnapshot = null
                    horizontalBlocked = false
                    velocity?.recycle()
                    velocity = VelocityTracker.obtain().also { it.addMovement(ev) }
                    val edge = dp(28f)   // у краёв — системный жест «назад»
                    if (!canSwipeNow() || ev.x < edge || ev.x > article.card.width - edge) {
                        dragState = DRAG_REJECTED
                    } else {
                        probeHorizontalScroll(ev.x, ev.y)
                    }
                    false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (dragState == DRAG_ACTIVE) springBack()
                    dragState = DRAG_REJECTED
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    velocity?.addMovement(ev)
                    val dx = ev.x - dragX0
                    val dy = ev.y - dragY0
                    if (dragState == DRAG_UNDECIDED) {
                        when {
                            horizontalBlocked || !canSwipeNow() -> dragState = DRAG_REJECTED
                            abs(dy) > slop && abs(dy) >= abs(dx) -> dragState = DRAG_REJECTED
                            abs(dx) > slop * 1.5f && abs(dx) > abs(dy) * 1.6f -> startDrag(v, ev)
                        }
                    }
                    if (dragState == DRAG_ACTIVE) {
                        applyDrag(dx); true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wasDragging = dragState == DRAG_ACTIVE
                    if (wasDragging) {
                        velocity?.addMovement(ev)
                        velocity?.computeCurrentVelocity(1000)
                        val vx = velocity?.xVelocity ?: 0f
                        finishDrag(ev.x - dragX0, vx, ev.actionMasked == MotionEvent.ACTION_CANCEL, minFling)
                    }
                    velocity?.recycle()
                    velocity = null
                    dragState = DRAG_UNDECIDED
                    wasDragging
                }
                else -> dragState == DRAG_ACTIVE
            }
        }
    }

    private fun canSwipeNow(): Boolean =
        articleOpen && transition == null && !capturing && pendingBack == null &&
            gesture == Gesture.NONE && customView == null && articleIndex >= 0 && articleList.size > 1

    private fun probeHorizontalScroll(x: Float, y: Float) {
        article.web.evaluateJavascript("$HSCROLL_JS(${x.roundToInt()},${y.roundToInt()})") { r ->
            if (r == "true") horizontalBlocked = true
        }
    }

    private fun startDrag(v: View, ev: MotionEvent) {
        dragState = DRAG_ACTIVE
        // Забираем касание у страницы, чтобы она не прокручивалась вместе с пальцем
        val cancel = MotionEvent.obtain(ev)
        cancel.action = MotionEvent.ACTION_CANCEL
        v.onTouchEvent(cancel)
        cancel.recycle()
        v.parent?.requestDisallowInterceptTouchEvent(true)
        article.card.animate().cancel()
        // Под статьёй — чистый фон страницы, а не лента
        underlay.setImageDrawable(null)
        underlay.setBackgroundColor(bottomColor)
        underlay.visibility = View.VISIBLE
        capture(article.card) { dragSnapshot = it }
        article.web.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun applyDrag(dx: Float) {
        val delta = if (dx < 0) 1 else -1
        val hasTarget = (articleIndex + delta) in articleList.indices
        val w = article.card.width.toFloat()
        val t = if (hasTarget) dx * 0.6f else dx * 0.18f     // у крайней статьи — упругое сопротивление
        article.card.translationX = t.coerceIn(-w * 0.45f, w * 0.45f)
    }

    private fun finishDrag(dx: Float, vx: Float, cancelled: Boolean, minFling: Float) {
        val delta = if (dx < 0) 1 else -1
        val target = articleIndex + delta
        val far = abs(dx) > article.card.width * 0.22f
        val flung = abs(vx) > minFling && (vx < 0) == (dx < 0)
        if (!cancelled && target in articleList.indices && (far || flung)) {
            swipeTo(target, delta)
        } else {
            springBack()
        }
    }

    private fun springBack() {
        article.card.anim().translationX(0f).setDuration(280).setInterpolator(emphasizedDecel)
            .withEndAction { if (transition == null) hideUnderlay() }.start()
    }

    private fun swipeTo(target: Int, delta: Int) {
        val url = articleList[target]
        articleIndex = target
        article.web.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        article.clearHistoryOnCommit = true   // свайп заменяет статью: «назад» ведёт в ленту
        article.snapshots.clear()
        article.failedUrl = null
        val bmp = dragSnapshot
        dragSnapshot = null
        if (bmp != null) {
            beginTransition(article, if (delta > 0) Dir.FORWARD else Dir.BACK, bmp, Style.PAGE, article.card.translationX)
        } else {
            springBack()
        }
        article.web.loadUrl(url)
    }

    // ───────────────────────────── Переходы внутри экрана ─────────────────────────────

    private fun navigateForward(layer: Layer, url: String) {
        if (capturing) return
        layer.failedUrl = null
        capture(layer.card) { bmp ->
            if (bmp != null) {
                cacheSnapshot(layer, layer.historyIndex, bmp)
                beginTransition(layer, Dir.FORWARD, bmp, Style.SHIFT)
            }
            layer.web.loadUrl(url)
        }
    }

    private fun goBackAnimated(layer: Layer) {
        if (capturing || !layer.web.canGoBack()) return
        layer.failedUrl = null
        capture(layer.card) { bmp ->
            if (bmp != null) beginTransition(layer, Dir.BACK, bmp, Style.SHIFT)
            layer.web.goBack()
        }
    }

    /** Уходящая страница замирает снимком поверх, пока грузится новая. */
    private fun beginTransition(layer: Layer, dir: Dir, bmp: Bitmap, style: Style, startOffset: Float = 0f) {
        transition = dir
        transitionStyle = style
        transitionLayer = layer
        transitionFromUrl = layer.web.url
        main.removeCallbacks(transitionTimeout)
        main.postDelayed(transitionTimeout, 10_000)

        overlay.animate().cancel()
        overlay.setImageBitmap(bmp)
        overlay.alpha = 1f
        overlay.translationX = startOffset
        overlay.visibility = View.VISIBLE

        // Карточка остаётся непрозрачной (чтобы под статьёй не просвечивала лента),
        // а проявляется только сама страница внутри неё.
        val card = layer.card
        val shift = if (style == Style.PAGE) card.width.toFloat() else dp(SHIFT_DP)
        card.animate().cancel()
        layer.web.animate().cancel()
        card.alpha = 1f
        card.translationY = 0f
        card.translationX = startOffset + if (dir == Dir.FORWARD) shift else -shift
        layer.web.alpha = if (style == Style.PAGE) 1f else 0f

        // Едва заметное «притухание», пока идёт загрузка
        if (style == Style.SHIFT) overlay.anim().alpha(0.88f).setDuration(450).setInterpolator(standard).start()
        updateBackCallback()
    }

    /**
     * SHIFT — shared axis X: старая страница уезжает и гаснет, новая выезжает навстречу.
     * PAGE — перелистывание: страницы целиком сменяют друг друга, как в ленте карточек.
     */
    private fun finishTransition() {
        val dir = transition ?: return
        val layer = transitionLayer ?: return
        transition = null
        transitionLayer = null
        transitionFromUrl = null
        main.removeCallbacks(transitionTimeout)
        val card = layer.card
        val page = transitionStyle == Style.PAGE
        val shift = if (page) card.width.toFloat() else dp(SHIFT_DP)

        overlay.anim()
            .alpha(if (page) 0.6f else 0f)
            .translationX(if (dir == Dir.FORWARD) -shift else shift)
            .setDuration(if (page) 380 else 300)
            .setInterpolator(emphasizedDecel)
            .withEndAction {
                overlay.visibility = View.GONE
                overlay.setImageDrawable(null)
                overlay.translationX = 0f
                if (page && pendingBack == null && gesture == Gesture.NONE) hideUnderlay()
            }.start()

        card.anim()
            .translationX(0f)
            .setDuration(if (page) 380 else 360)
            .setInterpolator(emphasizedDecel)
            .start()
        layer.web.anim()
            .alpha(1f)
            .setStartDelay(if (page) 0 else 40)
            .setDuration(if (page) 200 else 300)
            .setInterpolator(emphasizedDecel)
            .start()
        updateBackCallback()
    }

    private fun capture(card: View, done: (Bitmap?) -> Unit) {
        val w = card.width
        val h = card.height
        if (w <= 0 || h <= 0 || card.visibility != View.VISIBLE) {
            done(null); return
        }
        val bmp = try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            done(null); return
        }
        capturing = true
        val finish: (Bitmap?) -> Unit = { b ->
            capturing = false
            done(b)
        }
        val loc = IntArray(2)
        card.getLocationInWindow(loc)
        try {
            PixelCopy.request(window, Rect(loc[0], loc[1], loc[0] + w, loc[1] + h), bmp, { result ->
                finish(if (result == PixelCopy.SUCCESS) bmp else drawFallback(card))
            }, main)
        } catch (e: Exception) {
            finish(drawFallback(card))
        }
    }

    private fun drawFallback(card: View): Bitmap? = try {
        card.drawToBitmap()
    } catch (e: Exception) {
        null
    }

    private fun cacheSnapshot(layer: Layer, index: Int, bmp: Bitmap) {
        val scaled = try {
            Bitmap.createScaledBitmap(bmp, max(1, bmp.width / 2), max(1, bmp.height / 2), true)
        } catch (e: OutOfMemoryError) {
            return
        }
        val map = layer.snapshots
        map.keys.filter { it >= index }.forEach { map.remove(it) }
        map[index] = scaled
        while (map.size > MAX_SNAPSHOTS) map.remove(map.keys.min())
    }

    // ───────────────────────────── «Назад» и жест с предпросмотром ─────────────────────────────

    private fun onBack() {
        when {
            customView != null -> chrome.onHideCustomView()
            gesture != Gesture.NONE -> commitBackGesture()
            transition != null -> {
                transitionLayer?.web?.stopLoading()
                finishTransition()
            }
            pendingBack != null -> finishGestureBack()
            articleOpen -> if (article.web.canGoBack()) goBackAnimated(article) else closeArticle()
            feed.web.canGoBack() -> goBackAnimated(feed)
            else -> {
                backCallback.isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun startBackGesture(e: BackEventCompat) {
        gesture = Gesture.NONE
        gestureLayer = null
        if (customView != null || transition != null || pendingBack != null || capturing) return
        val layer = active
        when {
            articleOpen && !article.web.canGoBack() -> {
                gesture = Gesture.CLOSE_ARTICLE
                underlay.visibility = View.GONE
                underlayScrim.animate().cancel()
                underlayScrim.visibility = View.VISIBLE
                underlayScrim.alpha = FEED_DIM
            }
            layer.web.canGoBack() -> {
                gesture = Gesture.IN_LAYER
                underlay.setBackgroundColor(bottomColor)
                underlay.setImageBitmap(layer.snapshots[layer.historyIndex - 1])
                underlay.visibility = View.VISIBLE
                underlayScrim.animate().cancel()
                underlayScrim.alpha = GESTURE_DIM
                underlayScrim.visibility = View.VISIBLE
            }
            else -> return
        }
        gestureLayer = layer
        gestureDir = if (e.swipeEdge == BackEventCompat.EDGE_LEFT) 1f else -1f
        gestureStartY = e.touchY
        val card = layer.card
        card.animate().cancel()
        card.pivotX = card.width / 2f
        card.pivotY = card.height / 2f
        card.translationZ = 1f      // поверх снимка и затемнения
        card.clipToOutline = true
    }

    private fun progressBackGesture(e: BackEventCompat) {
        val card = gestureLayer?.card ?: return
        if (gesture == Gesture.NONE) return
        val p = e.progress
        val s = 1f - 0.1f * p
        card.scaleX = s
        card.scaleY = s
        card.translationX = gestureDir * dp(24f) * p
        val dy = (e.touchY - gestureStartY) * 0.1f
        card.translationY = dy.coerceIn(-dp(24f), dp(24f)) * p
        card.translationZ = 1f + dp(8f) * p
        setRadius(card, dp(28f) * min(1f, p * 3f))
        if (gesture == Gesture.CLOSE_ARTICLE) {
            feed.card.translationX = -dp(PARALLAX_DP) * (1f - p)
            underlayScrim.alpha = FEED_DIM * (1f - p)
        } else {
            underlayScrim.alpha = GESTURE_DIM * (1f - p)
        }
    }

    private fun cancelBackGesture() {
        val card = gestureLayer?.card ?: return
        val mode = gesture
        if (mode == Gesture.NONE) return
        gesture = Gesture.NONE
        gestureLayer = null
        val r0 = radii[card] ?: 0f
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 260
            interpolator = standard
            addUpdateListener { setRadius(card, r0 * (it.animatedValue as Float)) }
            start()
        }
        if (mode == Gesture.CLOSE_ARTICLE) {
            feed.card.anim().translationX(-dp(PARALLAX_DP)).setDuration(260).setInterpolator(standard).start()
            underlayScrim.anim().alpha(FEED_DIM).setDuration(260).setInterpolator(standard).start()
        } else {
            underlayScrim.anim().alpha(GESTURE_DIM).setDuration(260).setInterpolator(standard).start()
        }
        card.anim().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).translationZ(0f)
            .setDuration(260).setInterpolator(standard)
            .withEndAction {
                resetCard(card)
                if (mode == Gesture.IN_LAYER) {
                    hideUnderlay(); restoreScrim()
                }
            }.start()
    }

    private fun commitBackGesture() {
        val layer = gestureLayer ?: return
        val mode = gesture
        gesture = Gesture.NONE
        gestureLayer = null
        if (mode == Gesture.CLOSE_ARTICLE) {
            closeArticle(fromGesture = true)
            return
        }
        pendingBack = layer
        pendingBackFromUrl = layer.web.url
        layer.failedUrl = null
        main.removeCallbacks(gestureTimeout)
        main.postDelayed(gestureTimeout, 8_000)

        val card = layer.card
        underlayScrim.anim().alpha(0f).setDuration(200).setInterpolator(standard).start()
        card.anim()
            .alpha(0f)
            .scaleX(0.86f).scaleY(0.86f)
            .translationX(card.translationX + gestureDir * dp(48f))
            .setDuration(200)
            .setInterpolator(emphasizedAccel)
            .withEndAction {
                resetCard(card)
                card.alpha = 0f
                layer.web.goBack()
            }.start()
        updateBackCallback()
    }

    /** Предыдущая страница загрузилась — проявляем её поверх снимка. */
    private fun finishGestureBack() {
        val layer = pendingBack ?: return
        pendingBack = null
        pendingBackFromUrl = null
        main.removeCallbacks(gestureTimeout)
        layer.card.anim().alpha(1f).setDuration(220).setInterpolator(standard)
            .withEndAction { hideUnderlay(); restoreScrim() }.start()
        updateBackCallback()
    }

    private fun setRadius(card: View, r: Float) {
        radii[card] = r
        card.invalidateOutline()
    }

    private fun resetCard(card: View) {
        card.alpha = 1f
        card.scaleX = 1f
        card.scaleY = 1f
        card.translationX = 0f
        card.translationY = 0f
        card.translationZ = 0f
        setRadius(card, 0f)
        card.clipToOutline = false
    }

    private fun hideUnderlay() {
        underlay.visibility = View.GONE
        underlay.setImageDrawable(null)
    }

    /** Затемнение нужно только под открытой статьёй. */
    private fun restoreScrim() {
        if (articleOpen) {
            underlayScrim.visibility = View.VISIBLE
            underlayScrim.alpha = FEED_DIM
        } else {
            underlayScrim.visibility = View.GONE
            underlayScrim.alpha = 0f
        }
    }

    private fun updateBackCallback() {
        backCallback.isEnabled = customView != null || transition != null || pendingBack != null ||
            articleOpen || (websAlive && feed.web.canGoBack())
    }

    // ───────────────────────────── Прогресс, ошибки, цвета ─────────────────────────────

    private fun refreshError() {
        val l = active
        if (l.failedUrl != null && l.web.url == l.failedUrl) showError() else hideError()
    }

    private fun showError() {
        errorCode.text = errorDetail
        errorCode.visibility = if (errorDetail.isBlank()) View.GONE else View.VISIBLE
        if (transition != null) finishTransition()
        if (pendingBack != null) finishGestureBack()
        swipe.isRefreshing = false
        active.web.alpha = 1f
        if (errorView.visibility == View.VISIBLE && errorView.alpha >= 1f) return
        errorView.alpha = 0f
        errorView.scaleX = 0.96f
        errorView.scaleY = 0.96f
        errorView.visibility = View.VISIBLE
        errorView.anim().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300)
            .setInterpolator(emphasizedDecel).start()
    }

    private fun hideError() {
        if (errorView.visibility != View.VISIBLE) return
        errorView.anim().alpha(0f).setDuration(200).setInterpolator(standard)
            .withEndAction { errorView.visibility = View.GONE }.start()
    }

    /**
     * Страница сама сообщает свои цвета (при загрузке, прокрутке и смене темы на сайте) —
     * подложки статус-бара и навигации перекрашиваются сразу.
     */
    private inner class ColorBridge(val layer: Layer) {
        @JavascriptInterface
        fun colors(raw: String) {
            main.post { onPageColors(layer, raw) }
        }
    }

    private fun onPageColors(layer: Layer, raw: String) {
        val parts = raw.split('|').map { parseCssColor(it) }
        val page = parts.getOrNull(2) ?: return
        val c = Triple(parts.getOrNull(0) ?: page, parts.getOrNull(1) ?: page, page)
        layer.colors = c
        if (layer === active) applyColors(c.first, c.second, c.third)
    }

    /** Применить уже известные цвета активного экрана и попросить страницу пересчитать их. */
    private fun sampleColors() {
        if (!websAlive) return
        val layer = active
        layer.colors?.let { applyColors(it.first, it.second, it.third) }
        layer.web.evaluateJavascript("window.__rzkReport&&window.__rzkReport()", null)
    }

    private fun parseCssColor(c: String): Int? {
        val n = Regex("[\\d.]+").findAll(c).map { it.value.toFloatOrNull() ?: 0f }.toList()
        if (n.size < 3) return null
        if (n.size >= 4 && n[3] < 0.5f) return null
        return Color.rgb(n[0].toInt().coerceIn(0, 255), n[1].toInt().coerceIn(0, 255), n[2].toInt().coerceIn(0, 255))
    }

    private fun applyColors(top: Int, bottom: Int, page: Int) {
        if (top != topColor) animateBg(statusScrim, topColor, top)
        if (bottom != bottomColor) animateBg(navScrim, bottomColor, bottom)
        topColor = top
        bottomColor = bottom
        root.setBackgroundColor(page)
        for (l in listOf(feed, article)) {
            l.card.setBackgroundColor(page)
            l.web.setBackgroundColor(page)
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = ColorUtils.calculateLuminance(top) > 0.5
            isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(bottom) > 0.5
        }
    }

    private fun animateBg(v: View, from: Int, to: Int) {
        ValueAnimator.ofArgb(from, to).apply {
            duration = 250
            interpolator = standard
            addUpdateListener { v.setBackgroundColor(it.animatedValue as Int) }
            start()
        }
    }

    // ───────────────────────────── Кнопка «Поделиться» ─────────────────────────────

    private fun isArticle(url: String?): Boolean {
        val path = url?.let { Uri.parse(it).path } ?: return false
        return ARTICLE.containsMatchIn(path)
    }

    private fun articleId(url: String): String =
        ARTICLE_ID.find(Uri.parse(url).path ?: "")?.groupValues?.get(1) ?: url

    private fun refreshFab() {
        if (articleOpen && isArticle(article.web.url)) fab.show() else fab.hide()
    }

    private fun onArticleScroll(y: Int, oldY: Int) {
        if (!articleOpen || !isArticle(article.web.url)) return
        val dy = y - oldY
        if (abs(dy) < 4) return
        if (dy > 0) fab.hide() else fab.show()
    }

    // ───────────────────────────── Долгое нажатие на ссылку ─────────────────────────────

    private fun onWebLongPress(layer: Layer): Boolean {
        val web = layer.web
        val hit = web.hitTestResult
        return when (hit.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                val url = hit.extra ?: return false
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showLinkSheet(url, layer)
                true
            }
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                hrefFrom = layer
                web.requestFocusNodeHref(hrefHandler.obtainMessage())
                true
            }
            else -> false
        }
    }

    private fun showLinkSheet(url: String, from: Layer) {
        val dialog = BottomSheetDialog(this)
        val v = LayoutInflater.from(dialog.context).inflate(R.layout.sheet_link, null)
        v.findViewById<TextView>(R.id.linkTitle).text = prettyUrl(url)
        fun action(id: Int, block: () -> Unit) {
            v.findViewById<View>(id).setOnClickListener {
                dialog.dismiss()
                block()
            }
        }
        action(R.id.actOpen) {
            when {
                !isInternal(Uri.parse(url)) -> openExternal(url)
                from === feed && isArticle(url) -> openArticleFromFeed(url)
                else -> navigateForward(from, url)
            }
        }
        action(R.id.actShare) { share(url, null) }
        action(R.id.actCopy) { copy(url) }
        action(R.id.actBrowser) { openExternal(url, forceBrowser = true) }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun prettyUrl(url: String): String {
        val u = Uri.parse(url)
        val host = u.host?.removePrefix("www.") ?: return url
        val path = Uri.decode(u.path ?: "").trimEnd('/')
        return host + path
    }

    // ───────────────────────────── Внешние ссылки, «поделиться», буфер ─────────────────────────────

    private fun isInternal(uri: Uri): Boolean {
        val h = uri.host?.lowercase() ?: return false
        return h == "rozetked.me" || h.endsWith(".rozetked.me")
    }

    private fun isSameDocument(layer: Layer, url: String): Boolean {
        val cur = layer.web.url ?: return false
        return url.contains('#') && url.substringBefore('#') == cur.substringBefore('#')
    }

    private fun openExternal(url: String, forceBrowser: Boolean = false) {
        val intent: Intent = try {
            if (url.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
        } catch (e: Exception) {
            toast(getString(R.string.no_app)); return
        }
        if (forceBrowser || isInternal(Uri.parse(url))) defaultBrowserPackage()?.let { intent.setPackage(it) }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val fallback = intent.getStringExtra("browser_fallback_url")
            if (fallback != null) {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback))) }
                    .onFailure { toast(getString(R.string.no_app)) }
            } else {
                toast(getString(R.string.no_app))
            }
        }
    }

    /** Браузер по умолчанию — чтобы ссылки rozetked.me «в браузере» не возвращались в это приложение. */
    private fun defaultBrowserPackage(): String? {
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            .addCategory(Intent.CATEGORY_BROWSABLE)
        val pkg = packageManager.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName ?: return null
        return pkg.takeIf { it != "android" && it != packageName }
    }

    private fun share(url: String, title: String?) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
            if (!title.isNullOrBlank()) {
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TITLE, title)
            }
        }
        startActivity(Intent.createChooser(send, null))
    }

    private fun copy(url: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("link", url))
        if (Build.VERSION.SDK_INT < 33) toast(getString(R.string.copied))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────────────────────── Мелочи ─────────────────────────────

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Аниматор «с чистого листа»: сбрасывает задержку и слушатели от прошлых анимаций. */
    private fun View.anim(): ViewPropertyAnimator {
        animate().cancel()
        return animate().setStartDelay(0).setUpdateListener(null).setListener(null)
    }
}
