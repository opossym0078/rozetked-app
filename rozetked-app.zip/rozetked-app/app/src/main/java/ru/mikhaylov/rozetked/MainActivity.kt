package ru.mikhaylov.rozetked

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewPropertyAnimator
import android.view.animation.PathInterpolator
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.BackEventCompat
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.drawToBitmap
import androidx.core.view.updateLayoutParams
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    companion object {
        private const val HOME = "https://rozetked.me/"
        private const val SHIFT_DP = 56f          // сдвиг страниц при переходе (shared axis)
        private const val MAX_SNAPSHOTS = 8
        private val ARTICLE = Regex("^/(index\\.php/)?(news|articles|reviews|posts)/\\d+")
    }

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var card: FrameLayout
    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var overlay: ImageView
    private lateinit var underlay: ImageView
    private lateinit var underlayScrim: View
    private lateinit var progress: LinearProgressIndicator
    private lateinit var errorView: View
    private lateinit var errorCode: TextView
    private lateinit var statusScrim: View
    private lateinit var navScrim: View
    private lateinit var fab: FloatingActionButton
    private lateinit var fullscreen: FrameLayout

    private val main = Handler(Looper.getMainLooper())
    private val chrome = Chrome()

    // Снимки страниц по индексу истории — показываются под жестом «назад»
    private val snapshots = HashMap<Int, Bitmap>()
    private var historyIndex = 0

    private enum class Dir { FORWARD, BACK }

    private var transition: Dir? = null
    private var transitionFromUrl: String? = null
    private var capturing = false
    private var failedUrl: String? = null
    private var errorDetail: String = ""
    private var firstContentShown = false
    private var webAlive = true

    private var gestureActive = false
    private var gestureDir = 1f
    private var gestureStartY = 0f
    private var gestureBackPending = false
    private var gestureFromUrl: String? = null
    private var cardRadius = 0f

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private var topColor = 0
    private var bottomColor = 0
    private val startTime = SystemClock.uptimeMillis()

    // Кривые Material 3
    private val emphasizedDecel = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    private val emphasizedAccel = PathInterpolator(0.3f, 0f, 0.8f, 0.15f)
    private val standard = PathInterpolator(0.2f, 0f, 0f, 1f)

    private val transitionTimeout = Runnable { finishTransition() }
    private val gestureTimeout = Runnable { finishGestureBack() }
    private val hrefHandler = Handler(Looper.getMainLooper()) { msg ->
        msg.data?.getString("url")?.takeIf { it.isNotBlank() }?.let { showLinkSheet(it) }
        true
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackStarted(backEvent: BackEventCompat) = startBackGesture(backEvent)
        override fun handleOnBackProgressed(backEvent: BackEventCompat) = progressBackGesture(backEvent)
        override fun handleOnBackCancelled() = cancelBackGesture()
        override fun handleOnBackPressed() = onBack()
    }

    // ───────────────────────────── Жизненный цикл ─────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        card = findViewById(R.id.card)
        web = findViewById(R.id.web)
        swipe = findViewById(R.id.swipe)
        overlay = findViewById(R.id.overlay)
        underlay = findViewById(R.id.underlay)
        underlayScrim = findViewById(R.id.underlayScrim)
        progress = findViewById(R.id.progress)
        errorView = findViewById(R.id.errorView)
        errorCode = findViewById(R.id.errorCode)
        statusScrim = findViewById(R.id.statusScrim)
        navScrim = findViewById(R.id.navScrim)
        fab = findViewById(R.id.fabShare)
        fullscreen = findViewById(R.id.fullscreen)

        topColor = ContextCompat.getColor(this, R.color.page_bg)
        bottomColor = topColor

        val restoring = savedInstanceState != null
        splash.setKeepOnScreenCondition {
            !restoring && !firstContentShown && SystemClock.uptimeMillis() - startTime < 2500
        }
        splash.setOnExitAnimationListener { provider ->
            runCatching {
                provider.iconView.animate().scaleX(1.4f).scaleY(1.4f).alpha(0f)
                    .setDuration(320).setInterpolator(emphasizedAccel).start()
            }
            provider.view.animate().alpha(0f).setStartDelay(60).setDuration(300)
                .setInterpolator(standard).withEndAction { provider.remove() }.start()
        }

        setupInsets()
        setupCard()
        setupWeb()

        findViewById<MaterialButton>(R.id.retry).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            failedUrl = null
            hideError()
            if (web.url.isNullOrEmpty()) web.loadUrl(HOME) else web.reload()
        }
        fab.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            share(web.url ?: HOME, web.title)
        }

        onBackPressedDispatcher.addCallback(this, backCallback)

        val restored = savedInstanceState?.getBundle("web")?.let { web.restoreState(it) } != null
        if (!restored) {
            card.alpha = 0f
            web.loadUrl(initialUrl(intent))
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.data?.toString() ?: return
        if (!isInternal(Uri.parse(url))) return
        if (firstContentShown) navigateForward(url) else web.loadUrl(url)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (!webAlive) return
        val b = Bundle()
        runCatching { web.saveState(b) }
        outState.putBundle("web", b)
    }

    override fun onResume() {
        super.onResume()
        if (webAlive) web.onResume()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        if (webAlive) web.onPause()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        if (webAlive) {
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
            webAlive = false
        }
        super.onDestroy()
    }

    private fun initialUrl(intent: Intent?): String {
        val data = intent?.data ?: return HOME
        return if (isInternal(data)) data.toString() else HOME
    }

    // ───────────────────────────── Настройка ─────────────────────────────

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottom = max(bars.bottom, ime.bottom)
            content.setPadding(bars.left, bars.top, bars.right, bottom)
            statusScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.top }
            navScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.bottom }
            fab.updateLayoutParams<FrameLayout.LayoutParams> {
                bottomMargin = dp(20) + bottom
                rightMargin = dp(20) + bars.right
            }
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupCard() {
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cardRadius)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.setBackgroundColor(bottomColor)
        web.webViewClient = Client()
        web.webChromeClient = chrome
        web.setDownloadListener { url, _, _, _, _ -> openExternal(url, forceBrowser = true) }
        web.setOnLongClickListener { onWebLongPress() }
        web.setOnScrollChangeListener { _, _, y, _, oldY -> onWebScroll(y, oldY) }

        swipe.setColorSchemeColors(MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary))
        swipe.setProgressBackgroundColorSchemeColor(
            MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        )
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        swipe.setOnRefreshListener {
            failedUrl = null
            web.reload()
        }
    }

    // ───────────────────────────── WebView ─────────────────────────────

    private inner class Client : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (!request.isForMainFrame) return false
            val uri = request.url
            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") {
                openExternal(uri.toString()); return true
            }
            if (!isInternal(uri)) {
                openExternal(uri.toString()); return true
            }
            if (capturing) return true            // двойной тап во время перехода
            failedUrl = null
            if (request.isRedirect || transition != null || gestureBackPending) return false
            if (isSameDocument(uri.toString())) return false
            navigateForward(uri.toString())
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            showProgress()
        }

        override fun onPageCommitVisible(view: WebView, url: String?) {
            onContentVisible(url)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            hideProgress()
            swipe.isRefreshing = false
            onContentVisible(url)
            injectCss()
            main.postDelayed({ sampleColors() }, 150)
            updateBackCallback()
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            historyIndex = view.copyBackForwardList().currentIndex
            updateBackCallback()
            updateFab(url)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val desc = error.description?.toString().orEmpty()
            if (desc.contains("ERR_ABORTED")) return
            failedUrl = request.url.toString()
            errorDetail = "${error.errorCode} · $desc"
            showError()
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            webAlive = false
            (view.parent as? ViewGroup)?.removeView(view)
            view.destroy()
            recreate()
            return true
        }
    }

    private inner class Chrome : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.setProgressCompat(newProgress, true)
            if (newProgress >= 100) hideProgress() else showProgress()
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden(); return
            }
            customView = view
            customViewCallback = callback
            fullscreen.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fullscreen.alpha = 0f
            fullscreen.visibility = View.VISIBLE
            fullscreen.anim().alpha(1f).setDuration(200).setInterpolator(standard).start()
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            updateBackCallback()
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            customView = null
            fullscreen.removeView(v)
            fullscreen.visibility = View.GONE
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
            WindowInsetsControllerCompat(window, window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
            updateBackCallback()
        }
    }

    private fun onContentVisible(url: String?) {
        if (!firstContentShown) {
            firstContentShown = true
            // Первое появление: лёгкий подъём и проявление
            card.alpha = 0f
            card.translationY = dp(24f)
            card.anim().alpha(1f).translationY(0f).setDuration(480)
                .setInterpolator(emphasizedDecel).start()
        }
        if (failedUrl != null && url == failedUrl) {
            showError()
        } else {
            failedUrl = null
            hideError()
        }
        if (transition != null && url != transitionFromUrl) finishTransition()
        if (gestureBackPending && url != gestureFromUrl) finishGestureBack()
    }

    private fun injectCss() {
        web.evaluateJavascript(
            "(function(){if(document.getElementById('rzk-app'))return;" +
                "var s=document.createElement('style');s.id='rzk-app';" +
                "s.textContent='html{-webkit-tap-highlight-color:transparent}';" +
                "(document.head||document.documentElement).appendChild(s);})()",
            null
        )
    }

    // ───────────────────────────── Переходы между страницами ─────────────────────────────

    private fun navigateForward(url: String) {
        if (capturing) return
        failedUrl = null
        capture { bmp ->
            if (bmp != null) {
                cacheSnapshot(historyIndex, bmp)
                beginTransition(Dir.FORWARD, bmp)
            }
            web.loadUrl(url)
        }
    }

    private fun goBackAnimated() {
        if (capturing || !web.canGoBack()) return
        failedUrl = null
        capture { bmp ->
            if (bmp != null) beginTransition(Dir.BACK, bmp)
            web.goBack()
        }
    }

    /** Уходящая страница замирает снимком поверх, пока грузится новая. */
    private fun beginTransition(dir: Dir, bmp: Bitmap) {
        transition = dir
        transitionFromUrl = web.url
        main.removeCallbacks(transitionTimeout)
        main.postDelayed(transitionTimeout, 10_000)

        overlay.animate().cancel()
        overlay.setImageBitmap(bmp)
        overlay.alpha = 1f
        overlay.translationX = 0f
        overlay.visibility = View.VISIBLE

        card.animate().cancel()
        card.alpha = 0f
        card.translationY = 0f
        card.translationX = if (dir == Dir.FORWARD) dp(SHIFT_DP) else -dp(SHIFT_DP)

        // Едва заметное «притухание», пока идёт загрузка
        overlay.anim().alpha(0.88f).setDuration(450).setInterpolator(standard).start()
        updateBackCallback()
    }

    /** Shared axis X: старая страница уезжает и гаснет, новая выезжает навстречу. */
    private fun finishTransition() {
        val dir = transition ?: return
        transition = null
        transitionFromUrl = null
        main.removeCallbacks(transitionTimeout)
        val shift = dp(SHIFT_DP)

        overlay.anim()
            .alpha(0f)
            .translationX(if (dir == Dir.FORWARD) -shift else shift)
            .setDuration(300)
            .setInterpolator(emphasizedDecel)
            .withEndAction {
                overlay.visibility = View.GONE
                overlay.setImageDrawable(null)
                overlay.translationX = 0f
            }.start()

        card.anim()
            .alpha(1f)
            .translationX(0f)
            .setStartDelay(40)
            .setDuration(360)
            .setInterpolator(emphasizedDecel)
            .start()
        updateBackCallback()
    }

    private fun capture(done: (Bitmap?) -> Unit) {
        val w = card.width
        val h = card.height
        if (w <= 0 || h <= 0) {
            done(null); return
        }
        val bmp = try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            done(null); return
        }
        capturing = true
        val finish: (Bitmap?) -> Unit = { b ->
            capturing = false
            done(b)
        }
        val loc = IntArray(2)
        card.getLocationInWindow(loc)
        try {
            PixelCopy.request(window, Rect(loc[0], loc[1], loc[0] + w, loc[1] + h), bmp, { result ->
                finish(if (result == PixelCopy.SUCCESS) bmp else drawFallback())
            }, main)
        } catch (e: Exception) {
            finish(drawFallback())
        }
    }

    private fun drawFallback(): Bitmap? = try {
        card.drawToBitmap()
    } catch (e: Exception) {
        null
    }

    private fun cacheSnapshot(index: Int, bmp: Bitmap) {
        val scaled = try {
            Bitmap.createScaledBitmap(bmp, max(1, bmp.width / 2), max(1, bmp.height / 2), true)
        } catch (e: OutOfMemoryError) {
            return
        }
        snapshots.keys.filter { it >= index }.forEach { snapshots.remove(it) }
        snapshots[index] = scaled
        while (snapshots.size > MAX_SNAPSHOTS) snapshots.remove(snapshots.keys.min())
    }

    // ───────────────────────────── Жест «назад» с предпросмотром ─────────────────────────────

    private fun onBack() {
        when {
            customView != null -> chrome.onHideCustomView()
            gestureActive -> commitBackGesture()
            transition != null -> {
                web.stopLoading()
                finishTransition()
            }
            gestureBackPending -> finishGestureBack()
            web.canGoBack() -> goBackAnimated()
            else -> {
                backCallback.isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun startBackGesture(e: BackEventCompat) {
        gestureActive = false
        if (customView != null || transition != null || gestureBackPending || capturing || !web.canGoBack()) return
        gestureActive = true
        gestureDir = if (e.swipeEdge == BackEventCompat.EDGE_LEFT) 1f else -1f
        gestureStartY = e.touchY

        underlay.setBackgroundColor(bottomColor)
        underlay.setImageBitmap(snapshots[historyIndex - 1])
        underlay.visibility = View.VISIBLE
        underlayScrim.animate().cancel()
        underlayScrim.alpha = 0.32f
        underlayScrim.visibility = View.VISIBLE

        card.animate().cancel()
        card.pivotX = card.width / 2f
        card.pivotY = card.height / 2f
        card.clipToOutline = true
    }

    private fun progressBackGesture(e: BackEventCompat) {
        if (!gestureActive) return
        val p = e.progress
        val s = 1f - 0.1f * p
        card.scaleX = s
        card.scaleY = s
        card.translationX = gestureDir * dp(24f) * p
        val dy = (e.touchY - gestureStartY) * 0.1f
        card.translationY = dy.coerceIn(-dp(24f), dp(24f)) * p
        card.translationZ = dp(8f) * p
        setCardRadius(dp(28f) * min(1f, p * 3f))
        underlayScrim.alpha = 0.32f * (1f - p)
    }

    private fun cancelBackGesture() {
        if (!gestureActive) return
        gestureActive = false
        val r0 = cardRadius
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 260
            interpolator = standard
            addUpdateListener { setCardRadius(r0 * (it.animatedValue as Float)) }
            start()
        }
        underlayScrim.anim().alpha(0.32f).setDuration(260).setInterpolator(standard).start()
        card.anim().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).translationZ(0f)
            .setDuration(260).setInterpolator(standard)
            .withEndAction { resetCardChrome(); hideUnderlay() }
            .start()
    }

    private fun commitBackGesture() {
        gestureActive = false
        gestureBackPending = true
        gestureFromUrl = web.url
        failedUrl = null
        main.removeCallbacks(gestureTimeout)
        main.postDelayed(gestureTimeout, 8_000)

        underlayScrim.anim().alpha(0f).setDuration(200).setInterpolator(standard).start()
        card.anim()
            .alpha(0f)
            .scaleX(0.86f).scaleY(0.86f)
            .translationX(card.translationX + gestureDir * dp(48f))
            .setDuration(200)
            .setInterpolator(emphasizedAccel)
            .withEndAction {
                card.scaleX = 1f; card.scaleY = 1f
                card.translationX = 0f; card.translationY = 0f; card.translationZ = 0f
                resetCardChrome()
                web.goBack()
            }.start()
        updateBackCallback()
    }

    /** Предыдущая страница загрузилась — проявляем её поверх снимка. */
    private fun finishGestureBack() {
        if (!gestureBackPending) return
        gestureBackPending = false
        gestureFromUrl = null
        main.removeCallbacks(gestureTimeout)
        card.anim().alpha(1f).setDuration(220).setInterpolator(standard)
            .withEndAction { hideUnderlay() }.start()
        updateBackCallback()
    }

    private fun setCardRadius(r: Float) {
        cardRadius = r
        card.invalidateOutline()
    }

    private fun resetCardChrome() {
        setCardRadius(0f)
        card.clipToOutline = false
    }

    private fun hideUnderlay() {
        underlay.visibility = View.GONE
        underlay.setImageDrawable(null)
        underlayScrim.visibility = View.GONE
    }

    private fun updateBackCallback() {
        backCallback.isEnabled = customView != null || transition != null ||
            gestureBackPending || (webAlive && web.canGoBack())
    }

    // ───────────────────────────── Прогресс, ошибки, цвета ─────────────────────────────

    private fun showProgress() {
        if (progress.alpha >= 1f) return
        progress.anim().alpha(1f).setDuration(150).setInterpolator(standard).start()
    }

    private fun hideProgress() {
        progress.anim().alpha(0f).setStartDelay(200).setDuration(250).setInterpolator(standard)
            .withEndAction { progress.setProgressCompat(0, false) }.start()
    }

    private fun showError() {
        errorCode.text = errorDetail
        errorCode.visibility = if (errorDetail.isBlank()) View.GONE else View.VISIBLE
        if (transition != null) finishTransition()
        if (gestureBackPending) finishGestureBack()
        swipe.isRefreshing = false
        if (errorView.visibility == View.VISIBLE) return
        errorView.alpha = 0f
        errorView.scaleX = 0.96f
        errorView.scaleY = 0.96f
        errorView.visibility = View.VISIBLE
        errorView.anim().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300)
            .setInterpolator(emphasizedDecel).start()
    }

    private fun hideError() {
        if (errorView.visibility != View.VISIBLE) return
        errorView.anim().alpha(0f).setDuration(200).setInterpolator(standard)
            .withEndAction { errorView.visibility = View.GONE }.start()
    }

    /** Красим подложки статус-бара и навигации в цвет шапки и фона страницы. */
    private fun sampleColors() {
        if (!webAlive) return
        val js = """(function(){function bg(e){while(e&&e.nodeType===1){var c=getComputedStyle(e).backgroundColor;if(c&&c!=='transparent'&&!/rgba\([^)]*,\s*0\)$/.test(c))return c;e=e.parentElement;}return '';}var w=innerWidth/2;var t=document.elementFromPoint(w,1),b=document.elementFromPoint(w,innerHeight-1);var d=bg(document.body)||bg(document.documentElement);return [bg(t)||d,bg(b)||d,d].join('|');})()"""
        web.evaluateJavascript(js) { result ->
            val raw = runCatching { JSONTokener(result).nextValue() as? String }.getOrNull() ?: return@evaluateJavascript
            val parts = raw.split('|').map { parseCssColor(it) }
            val page = parts.getOrNull(2) ?: return@evaluateJavascript
            applyColors(parts.getOrNull(0) ?: page, parts.getOrNull(1) ?: page, page)
        }
    }

    private fun parseCssColor(c: String): Int? {
        val n = Regex("[\\d.]+").findAll(c).map { it.value.toFloatOrNull() ?: 0f }.toList()
        if (n.size < 3) return null
        if (n.size >= 4 && n[3] < 0.5f) return null
        return Color.rgb(n[0].toInt().coerceIn(0, 255), n[1].toInt().coerceIn(0, 255), n[2].toInt().coerceIn(0, 255))
    }

    private fun applyColors(top: Int, bottom: Int, page: Int) {
        if (top != topColor) animateBg(statusScrim, topColor, top)
        if (bottom != bottomColor) animateBg(navScrim, bottomColor, bottom)
        topColor = top
        bottomColor = bottom
        root.setBackgroundColor(page)
        card.setBackgroundColor(page)
        web.setBackgroundColor(page)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = ColorUtils.calculateLuminance(top) > 0.5
            isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(bottom) > 0.5
        }
    }

    private fun animateBg(v: View, from: Int, to: Int) {
        ValueAnimator.ofArgb(from, to).apply {
            duration = 250
            interpolator = standard
            addUpdateListener { v.setBackgroundColor(it.animatedValue as Int) }
            start()
        }
    }

    // ───────────────────────────── Кнопка «Поделиться» ─────────────────────────────

    private fun isArticle(url: String?): Boolean {
        val path = url?.let { Uri.parse(it).path } ?: return false
        return ARTICLE.containsMatchIn(path)
    }

    private fun updateFab(url: String?) {
        if (isArticle(url)) fab.show() else fab.hide()
    }

    private fun onWebScroll(y: Int, oldY: Int) {
        if (!isArticle(web.url)) return
        val dy = y - oldY
        if (abs(dy) < 4) return
        if (dy > 0) fab.hide() else fab.show()
    }

    // ───────────────────────────── Долгое нажатие на ссылку ─────────────────────────────

    private fun onWebLongPress(): Boolean {
        val hit = web.hitTestResult
        return when (hit.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                val url = hit.extra ?: return false
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showLinkSheet(url)
                true
            }
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                web.requestFocusNodeHref(hrefHandler.obtainMessage())
                true
            }
            else -> false
        }
    }

    private fun showLinkSheet(url: String) {
        val dialog = BottomSheetDialog(this)
        val v = LayoutInflater.from(dialog.context).inflate(R.layout.sheet_link, null)
        v.findViewById<TextView>(R.id.linkTitle).text = prettyUrl(url)
        fun action(id: Int, block: () -> Unit) {
            v.findViewById<View>(id).setOnClickListener {
                dialog.dismiss()
                block()
            }
        }
        action(R.id.actOpen) {
            if (isInternal(Uri.parse(url))) navigateForward(url) else openExternal(url)
        }
        action(R.id.actShare) { share(url, null) }
        action(R.id.actCopy) { copy(url) }
        action(R.id.actBrowser) { openExternal(url, forceBrowser = true) }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun prettyUrl(url: String): String {
        val u = Uri.parse(url)
        val host = u.host?.removePrefix("www.") ?: return url
        val path = Uri.decode(u.path ?: "").trimEnd('/')
        return host + path
    }

    // ───────────────────────────── Внешние ссылки, «поделиться», буфер ─────────────────────────────

    private fun isInternal(uri: Uri): Boolean {
        val h = uri.host?.lowercase() ?: return false
        return h == "rozetked.me" || h.endsWith(".rozetked.me")
    }

    private fun isSameDocument(url: String): Boolean {
        val cur = web.url ?: return false
        return url.contains('#') && url.substringBefore('#') == cur.substringBefore('#')
    }

    private fun openExternal(url: String, forceBrowser: Boolean = false) {
        val intent: Intent = try {
            if (url.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
        } catch (e: Exception) {
            toast(getString(R.string.no_app)); return
        }
        if (forceBrowser || isInternal(Uri.parse(url))) defaultBrowserPackage()?.let { intent.setPackage(it) }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val fallback = intent.getStringExtra("browser_fallback_url")
            if (fallback != null) {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback))) }
                    .onFailure { toast(getString(R.string.no_app)) }
            } else {
                toast(getString(R.string.no_app))
            }
        }
    }

    /** Браузер по умолчанию — чтобы ссылки rozetked.me «в браузере» не возвращались в это приложение. */
    private fun defaultBrowserPackage(): String? {
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            .addCategory(Intent.CATEGORY_BROWSABLE)
        val pkg = packageManager.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName ?: return null
        return pkg.takeIf { it != "android" && it != packageName }
    }

    private fun share(url: String, title: String?) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
            if (!title.isNullOrBlank()) {
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TITLE, title)
            }
        }
        startActivity(Intent.createChooser(send, null))
    }

    private fun copy(url: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("link", url))
        if (Build.VERSION.SDK_INT < 33) toast(getString(R.string.copied))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────────────────────── Мелочи ─────────────────────────────

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Аниматор «с чистого листа»: сбрасывает задержку и слушатели от прошлых анимаций. */
    private fun View.anim(): ViewPropertyAnimator {
        animate().cancel()
        return animate().setStartDelay(0).setUpdateListener(null).setListener(null)
    }
}
