package ru.mikhaylov.rozetked

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewPropertyAnimator
import android.view.animation.PathInterpolator
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.BackEventCompat
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.drawToBitmap
import androidx.core.view.updateLayoutParams
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        private const val HOME = "https://rozetked.me/"
        private const val BLANK = "about:blank"
        private const val SHIFT_DP = 48f          // сдвиг при переходе по ссылке внутри экрана
        private const val ANIM_SLOWDOWN = 1.6f    // общий множитель длительности анимаций
        private const val FEED_DIM = 0.12f        // лента под статьёй не двигается, лишь слегка темнеет
        private const val GESTURE_DIM = 0.3f
        private const val PAGER_MIN_SCALE = 0.86f // насколько уменьшаются карточки при листании
        private const val PAGER_GAP_DP = 14f      // зазор между карточками
        private const val MAX_SNAPSHOTS = 8
        private const val TEXT_ZOOM_FACTOR = 0.9f
        private const val DRAG_UNDECIDED = 0
        private const val DRAG_ACTIVE = 1
        private const val DRAG_REJECTED = 2
        private val ARTICLE = Regex("^/(index\\.php/)?(news|articles|reviews|posts)/\\d+")
        private val ARTICLE_ID = Regex("/(?:news|articles|reviews|posts)/(\\d+)")
        private val SCRIPT_ORIGINS = setOf("https://rozetked.me", "https://*.rozetked.me")

        /**
         * Встраивается в каждую страницу (только верхний фрейм):
         *  • прячет «Подписывайтесь на Rozetked…», «Поделитесь публикацией…» и подвал сайта —
         *    берётся самый крупный контейнер, в котором нет ничего, кроме этих блоков;
         *  • сообщает приложению цвета шапки и низа страницы, в том числе при смене темы на сайте;
         *  • запоминает, на какой блок ленты нажали — из него «раскрывается» статья.
         */
        private const val PAGE_JS = """(function(){
if(window.top!==window||window.__rzk)return;window.__rzk=1;
var SK='rzkSel2';var SEL;try{SEL=JSON.parse(localStorage.getItem(SK)||'{}');}catch(e){SEL={};}SEL.junk=SEL.junk||[];SEL.hdr=SEL.hdr||[];SEL.pad=SEL.pad||[];
function saveSel(){try{localStorage.setItem(SK,JSON.stringify(SEL));}catch(e){}}
function preStyle(){var all=SEL.junk.slice();if(isArt())all=all.concat(SEL.hdr);
var st=document.getElementById('rzk-pre');if(!st){st=document.createElement('style');st.id='rzk-pre';(document.head||document.documentElement).appendChild(st);}
st.textContent=(all.length?all.join(',')+'{display:none!important}':'')+(isArt()?SEL.pad.join(''):'');}
preStyle();
function N(s){return (s||'').replace(/[\s  ]+/g,' ').trim().toLowerCase();}
function addStyle(){if(document.getElementById('rzk-app'))return;var s=document.createElement('style');s.id='rzk-app';
s.textContent='html{-webkit-tap-highlight-color:transparent}.rzk-hide{display:none!important}';
(document.head||document.documentElement).appendChild(s);}
function vis(e){var t=e.innerText;return N(typeof t==='string'?t:e.textContent);}
var JUNK=[/подписывайтесь на[^.!]*[.!]?/g,/поделитесь публикацией с друзьями/g,/поделитесь публикацией/g,/пользовательское соглашение/g,/rozetked\s*©\s*\d*/g,/контакты/g,/реклама/g,/о проекте/g,/\b(telegram|vk|youtube|viber|whatsapp|twitter|ok)\b/g,/вконтакте|одноклассники|дзен|телеграм/g];
function rest(e){var t=vis(e);for(var i=0;i<JUNK.length;i++)t=t.replace(JUNK[i],' ');return t.replace(/[\s\d.,:;!|•·©—–\-]+/g,'');}
function locate(first,phrase){var res=[];if(!document.body)return res;var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);var n;
while((n=w.nextNode())){if(N(n.nodeValue).indexOf(first)<0)continue;var e=n.parentElement,k=0;
while(e&&k<6&&N(e.textContent).indexOf(phrase)<0){e=e.parentElement;k++;}
if(e&&e!==document.body&&e!==document.documentElement&&!e.closest('.rzk-hide'))res.push(e);}return res;}
function hideBlock(first,phrase){locate(first,phrase).forEach(function(el){if(el.closest('.rzk-hide'))return;
while(el.parentElement&&el.parentElement!==document.body&&el.parentElement!==document.documentElement&&rest(el.parentElement)==='')el=el.parentElement;
el.classList.add('rzk-hide');learn('junk',el);});}
function isArt(){return /^\/(index\.php\/)?(news|articles|reviews|posts)\/\d+/.test(location.pathname);}
function hideHeader(){if(!isArt()||window.__rzkHdr||!document.body)return;
var logo=document.querySelector('img[src*="logo"]'),cand=null;
if(logo){var e=logo;while(e&&e!==document.body&&e!==document.documentElement){var r=e.getBoundingClientRect();
if(r.height>=160)break;if(r.top<=2&&r.height>0&&r.width>=innerWidth*0.9)cand=e;e=e.parentElement;}}
if(!cand){var h=document.querySelector('header');if(h){var r2=h.getBoundingClientRect();if(r2.top<=2&&r2.height>0&&r2.height<160)cand=h;}}
if(!cand)return;var hh=cand.getBoundingClientRect().height;cand.classList.add('rzk-hide');window.__rzkHdr=1;learn('hdr',cand);
var els=[document.documentElement,document.body].concat([].slice.call(document.body.children,0,4));
els.forEach(function(el){var cs=getComputedStyle(el);var pt=parseFloat(cs.paddingTop)||0,mt=parseFloat(cs.marginTop)||0;
var sl=el===document.documentElement?'html':el===document.body?'body':selFor(el);
function fix(prop){el.style.setProperty(prop,'0px','important');if(sl){var rule=sl+'{'+prop+':0px!important}';if(SEL.pad.indexOf(rule)<0){SEL.pad.push(rule);if(SEL.pad.length>6)SEL.pad.shift();saveSel();}}}
if(pt>=hh*0.7&&pt<=hh*1.6)fix('padding-top');
if(mt>=hh*0.7&&mt<=hh*1.6)fix('margin-top');});}
function plain(e){var w=document.createTreeWalker(e,4,null),n,o='';while((n=w.nextNode())){var p=n.parentElement;if(p&&/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(p.tagName))continue;o+=n.nodeValue+' ';}return o;}
function junkLeft(t){t=N(t);for(var i=0;i<JUNK.length;i++)t=t.replace(JUNK[i],' ');return t.replace(/[\s\d.,:;!|•·©—–\-]+/g,'');}
function cls(e){return [].filter.call(e.classList||[],function(c){return c!=='rzk-hide'&&/^[a-zA-Z_-][\w-]*$/.test(c)&&!/\d{3,}/.test(c);});}
function selFor(el){if(el.id&&/^[a-zA-Z][\w-]*$/.test(el.id))return '#'+el.id;var parts=[],e=el;
for(var d=0;d<4&&e&&e!==document.body&&e!==document.documentElement;d++){var c=cls(e);parts.unshift(e.tagName.toLowerCase()+(c.length?'.'+c.join('.'):''));
var sel=parts.join(' > ');if(parts.some(function(x){return x.indexOf('.')>0;})){try{var m=document.querySelectorAll(sel);if(m.length===1&&m[0]===el)return sel;}catch(x){}}e=e.parentElement;}return null;}
function learn(kind,el){var sl=selFor(el);if(!sl)return;var a=SEL[kind];if(a.indexOf(sl)<0){a.push(sl);if(a.length>12)a.shift();saveSel();}}
function verify(){if(!document.body)return;var changed=false;
SEL.junk=SEL.junk.filter(function(sl){var ok=true;try{document.querySelectorAll(sl).forEach(function(e){if(junkLeft(plain(e))!=='')ok=false;});}catch(x){ok=false;}if(!ok)changed=true;return ok;});
if(isArt())SEL.hdr=SEL.hdr.filter(function(sl){var ok=true;try{document.querySelectorAll(sl).forEach(function(e){if(!(e.tagName==='HEADER'||e.querySelector('img[src*="logo"]'))||e.querySelector('h1'))ok=false;});}catch(x){ok=false;}if(!ok)changed=true;return ok;});
if(changed){saveSel();preStyle();}}
function clean(){addStyle();if(!document.body)return;
hideHeader();
hideBlock('подписывайтесь','подписывайтесь на');
hideBlock('поделитесь','поделитесь публикацией');
hideBlock('пользовательское','пользовательское соглашение');
if(document.readyState!=='loading'&&!window.__rzkSent){window.__rzkSent=1;try{RzkApp.cleaned();}catch(e){}}}
function bg(e){while(e&&e.nodeType===1){var c=getComputedStyle(e).backgroundColor;if(c&&c!=='transparent'&&!/rgba\([^)]*,\s*0\)$/.test(c))return c;e=e.parentElement;}return '';}
function report(){try{if(!document.body)return;var w=innerWidth/2;var t=document.elementFromPoint(w,1),b=document.elementFromPoint(w,innerHeight-1);
var d=bg(document.body)||bg(document.documentElement);var s=[bg(t)||d,bg(b)||d,d].join('|');
if(s!==window.__rzkLast){window.__rzkLast=s;if(window.RzkApp)RzkApp.colors(s);}}catch(e){}}
window.__rzkReport=function(){window.__rzkLast='';report();};
var rt;function soon(){clearTimeout(rt);rt=setTimeout(report,60);setTimeout(report,450);}
var ct;addEventListener('scroll',function(){clearTimeout(rt);rt=setTimeout(report,120);clearTimeout(ct);ct=setTimeout(clean,300);},{passive:true});
addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[href]');if(a)window.__rzkTapA=a;soon();},true);
addEventListener('touchstart',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[href]');if(a)window.__rzkTapA=a;},{capture:true,passive:true});
try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',soon);}catch(e){}
var opts={attributes:true,attributeFilter:['class','style','data-theme','data-mode','data-color-scheme']};
var ao=new MutationObserver(soon);function watch(){ao.observe(document.documentElement,opts);if(document.body)ao.observe(document.body,opts);}
function all(){if(document.readyState!=='loading')verify();clean();watch();soon();}
all();
document.addEventListener('DOMContentLoaded',all);addEventListener('load',all);
new MutationObserver(function(){clearTimeout(window.__rzkT);window.__rzkT=setTimeout(clean,150);})
.observe(document.documentElement,{childList:true,subtree:true});
})()"""

        /**
         * Для статьи по ссылке href: список всех статей ленты по порядку (для колоды)
         * и прямоугольник её блока на экране (из него статья раскрывается и в него сворачивается).
         */
        private const val FEED_INFO_JS = """(function(href){
function idOf(u){try{var p=new URL(u,location.href).pathname;var m=p.match(/\/(?:news|articles|reviews|posts)\/(\d+)/);return m?m[1]:null;}catch(e){return null;}}
var re=/^\/(index\.php\/)?(news|articles|reviews|posts)\/\d+/;var seen={},out=[];var as=document.querySelectorAll('a[href]');
for(var i=0;i<as.length;i++){var u;try{u=new URL(as[i].href,location.href);}catch(e){continue;}
if(!/(^|\.)rozetked\.me$/.test(u.hostname)||!re.test(u.pathname))continue;var k=idOf(u.href);if(!k||seen[k])continue;seen[k]=1;out.push(u.origin+u.pathname);}
var id=idOf(href);var a=window.__rzkTapA;
if(!a||!a.isConnected||idOf(a.href)!==id){a=null;for(var j=0;j<as.length;j++){if(idOf(as[j].href)!==id)continue;var r0=as[j].getBoundingClientRect();
if(r0.width>0&&r0.height>0&&r0.bottom>0&&r0.top<innerHeight){a=as[j];break;}}}
var rect=null;if(a){var e=a;while(e.parentElement&&e.parentElement!==document.body){var p=e.parentElement;var pr=p.getBoundingClientRect();
if(pr.height>innerHeight*0.6||pr.width>innerWidth+1)break;var ids={},n=0;var ps=p.querySelectorAll('a[href]');
for(var q=0;q<ps.length;q++){var x=idOf(ps[q].href);if(x&&!ids[x]){ids[x]=1;n++;}}if(n>1)break;e=p;}
var r=e.getBoundingClientRect();if(r.width>8&&r.height>8&&r.bottom>0&&r.top<innerHeight)rect=[r.left,r.top,r.width,r.height];}
return JSON.stringify({list:out,rect:rect,dpr:window.devicePixelRatio||1});})"""

        /** Нельзя листать, если страница увеличена щипком или под пальцем карусель/широкая таблица. */
        private const val HSCROLL_JS = """(function(px,py){if(window.visualViewport&&visualViewport.scale>1.05)return true;
var r=window.devicePixelRatio||1;var e=document.elementFromPoint(px/r,py/r);
while(e&&e!==document.body&&e!==document.documentElement){var s=getComputedStyle(e);
if((s.overflowX==='auto'||s.overflowX==='scroll')&&e.scrollWidth>e.clientWidth+4&&!e.querySelector('h1'))return true;
var c=typeof e.className==='string'?e.className:'';if(/swiper|slick|carousel|splide|glide|owl-/i.test(c))return true;
e=e.parentElement;}return false;})"""

        private const val PAUSE_MEDIA_JS =
            "document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})"
    }

    /** Один «экран»: лента или одна из карт-статей. У каждого своя WebView, история и снимки. */
    private inner class Layer(val card: FrameLayout, val web: WebView, val isFeed: Boolean) {
        val snapshots = HashMap<Int, Bitmap>()
        var historyIndex = 0
        var failedUrl: String? = null
        var clearHistoryOnCommit = false
        var colors: Triple<Int, Int, Int>? = null
        var wantUrl: String? = null          // для карт-статей: какая статья сюда загружена
        var ready = false
        var outlineRect: RectF? = null       // контур во время «раскрытия»
        var radius = 0f
        var awaitingFade = false
        var fadeFromUrl: String? = null
        var committed = false               // новый документ показал первый кадр
        var cleanedSeen = false             // скрипт уже убрал шапку и нижние блоки
        val fadeTimeout = Runnable { fadeInContent(this) }
        val gateTimeout = Runnable { fadeInContent(this) }
    }

    private enum class Dir { FORWARD, BACK }
    private enum class Gesture { NONE, IN_LAYER, CLOSE_ARTICLE }

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var overlay: ImageView
    private lateinit var morph: ImageView
    private lateinit var underlay: ImageView
    private lateinit var underlayScrim: View
    private lateinit var errorView: View
    private lateinit var errorCode: TextView
    private lateinit var statusScrim: View
    private lateinit var navScrim: View
    private lateinit var fab: FloatingActionButton
    private lateinit var fullscreen: FrameLayout

    private lateinit var feed: Layer
    private lateinit var slots: List<Layer>
    private lateinit var article: Layer      // текущая карта
    private lateinit var nextSlot: Layer     // следующая статья, предзагружена
    private lateinit var prevSlot: Layer     // предыдущая статья, предзагружена
    private var articleOpen = false
    private val active: Layer get() = if (articleOpen) article else feed
    private val allLayers: List<Layer> get() = listOf(feed) + slots

    private val main = Handler(Looper.getMainLooper())
    private val chrome = Chrome()

    // Слои по высоте
    private var zTop = 0f
    private var zBehind = 0f
    private var zOver = 0f

    // Переход по ссылке внутри экрана (короткий, не ждёт загрузки)
    private var transitionBusy = false
    private val transitionDone = Runnable { transitionBusy = false; updateBackCallback() }
    private var capturing = false

    // Раскрытие/сворачивание статьи
    private var morphAnim: ValueAnimator? = null
    private var openedItem: Pair<String, Bitmap>? = null
    private var opening = false
    private var closing = false

    // Жест «назад»
    private var gesture = Gesture.NONE
    private var gestureLayer: Layer? = null
    private var gestureDir = 1f
    private var gestureStartY = 0f
    private var pendingBack: Layer? = null
    private var pendingBackFromUrl: String? = null

    // Колода статей
    private var articleList: List<String> = emptyList()
    private var articleIndex = -1
    private var horizontalBlocked = false
    private var dragState = DRAG_UNDECIDED
    private var dragX0 = 0f
    private var dragY0 = 0f
    private var deckAnimating = false
    private var pagerOffset = 0f
    private var pagerScale = 1f
    private var pagerAnim: ValueAnimator? = null
    private var velocity: VelocityTracker? = null
    private val neighborsTask = Runnable { ensureNeighbors() }

    private var errorDetail = ""
    private var firstContentShown = false
    private var websAlive = true
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private var topColor = 0
    private var bottomColor = 0
    private val startTime = SystemClock.uptimeMillis()

    // Кривые Material 3
    private val emphasizedDecel = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    private val emphasizedAccel = PathInterpolator(0.3f, 0f, 0.8f, 0.15f)
    private val standard = PathInterpolator(0.2f, 0f, 0f, 1f)

    private val gestureTimeout = Runnable { finishGestureBack() }
    private var hrefFrom: Layer? = null
    private val hrefHandler = Handler(Looper.getMainLooper()) { msg ->
        val from = hrefFrom
        msg.data?.getString("url")?.takeIf { it.isNotBlank() }?.let { if (from != null) showLinkSheet(it, from) }
        true
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackStarted(backEvent: BackEventCompat) = startBackGesture(backEvent)
        override fun handleOnBackProgressed(backEvent: BackEventCompat) = progressBackGesture(backEvent)
        override fun handleOnBackCancelled() = cancelBackGesture()
        override fun handleOnBackPressed() = onBack()
    }

    // ───────────────────────────── Жизненный цикл ─────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        swipe = findViewById(R.id.swipe)
        overlay = findViewById(R.id.overlay)
        morph = findViewById(R.id.morph)
        underlay = findViewById(R.id.underlay)
        underlayScrim = findViewById(R.id.underlayScrim)
        errorView = findViewById(R.id.errorView)
        errorCode = findViewById(R.id.errorCode)
        statusScrim = findViewById(R.id.statusScrim)
        navScrim = findViewById(R.id.navScrim)
        fab = findViewById(R.id.fabShare)
        fullscreen = findViewById(R.id.fullscreen)

        zBehind = dp(1f)
        zTop = dp(3f)
        zOver = dp(5f)
        overlay.elevation = dp(10f)
        morph.elevation = dp(10f)
        errorView.elevation = dp(14f)

        topColor = ContextCompat.getColor(this, R.color.page_bg)
        bottomColor = topColor

        val restoring = savedInstanceState != null
        splash.setKeepOnScreenCondition {
            !restoring && !firstContentShown && SystemClock.uptimeMillis() - startTime < 2500
        }
        splash.setOnExitAnimationListener { provider ->
            runCatching {
                provider.iconView.animate().scaleX(1.4f).scaleY(1.4f).alpha(0f)
                    .setDuration(ms(280)).setInterpolator(emphasizedAccel).start()
            }
            provider.view.animate().alpha(0f).setStartDelay(40).setDuration(ms(260))
                .setInterpolator(standard).withEndAction { provider.remove() }.start()
        }

        feed = Layer(findViewById(R.id.feedCard), findViewById(R.id.feedWeb), true)
        setupInsets()
        setupCard(feed)
        setupWeb(feed)
        setupFeedRefresh()
        slots = List(3) { createSlot() }
        article = slots[0]
        nextSlot = slots[1]
        prevSlot = slots[2]

        findViewById<MaterialButton>(R.id.retry).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val l = active
            l.failedUrl = null
            hideError()
            val url = l.web.url
            if (url.isNullOrEmpty() || url == BLANK) l.web.loadUrl(l.wantUrl ?: HOME) else l.web.reload()
        }
        fab.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            share(article.web.url ?: HOME, article.web.title)
        }

        onBackPressedDispatcher.addCallback(this, backCallback)

        val restored = savedInstanceState?.getBundle("feed")?.let { feed.web.restoreState(it) } != null
        if (!restored) {
            content.alpha = 0f
            val data = intent?.data
            if (data != null && isInternal(data) && !isArticle(data.toString())) {
                feed.web.loadUrl(data.toString())
            } else {
                feed.web.loadUrl(HOME)
                if (data != null && isInternal(data)) showArticle(data.toString(), null, null)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.data?.toString() ?: return
        if (!isInternal(Uri.parse(url))) return
        when {
            isArticle(url) && articleOpen -> navigateForward(article, url)
            isArticle(url) -> {
                articleList = emptyList(); articleIndex = -1
                showArticle(url, null, null)
            }
            else -> {
                if (articleOpen) closeArticle()
                navigateForward(feed, url)
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (!websAlive) return
        val b = Bundle()
        runCatching { feed.web.saveState(b) }
        outState.putBundle("feed", b)
    }

    override fun onResume() {
        super.onResume()
        if (!websAlive) return
        feed.web.onResume()
        if (articleOpen) slots.forEach { it.web.onResume() }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        if (websAlive) allLayers.forEach { it.web.onPause() }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        destroyWebs()
        super.onDestroy()
    }

    private fun destroyWebs() {
        if (!websAlive) return
        websAlive = false
        for (l in allLayers) {
            (l.web.parent as? ViewGroup)?.removeView(l.web)
            runCatching { l.web.destroy() }
        }
    }

    // ───────────────────────────── Настройка ─────────────────────────────

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottom = max(bars.bottom, ime.bottom)
            content.setPadding(bars.left, bars.top, bars.right, bottom)
            statusScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.top }
            navScrim.updateLayoutParams<FrameLayout.LayoutParams> { height = bars.bottom }
            fab.updateLayoutParams<FrameLayout.LayoutParams> {
                bottomMargin = dp(20) + bottom
                rightMargin = dp(20) + bars.right
            }
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupCard(layer: Layer) {
        layer.card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = layer.outlineRect
                if (r != null) {
                    outline.setRoundRect(r.left.roundToInt(), r.top.roundToInt(), r.right.roundToInt(), r.bottom.roundToInt(), layer.radius)
                } else {
                    outline.setRoundRect(0, 0, view.width, view.height, layer.radius)
                }
            }
        }
    }

    /** Карта-статья: своя WebView поверх ленты. Скрытые карты держат предзагруженные статьи. */
    private fun createSlot(): Layer {
        val card = FrameLayout(this)
        card.setBackgroundColor(ContextCompat.getColor(this, R.color.page_bg))
        val web = WebView(this)
        web.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        card.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.visibility = View.INVISIBLE
        content.addView(card, content.indexOfChild(morph),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val layer = Layer(card, web, false)
        setupCard(layer)
        setupWeb(layer)
        setupDeckSwipes(layer)
        return layer
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(layer: Layer) {
        val web = layer.web
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = max(50, (textZoom * TEXT_ZOOM_FACTOR).roundToInt())
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.setBackgroundColor(bottomColor)
        web.addJavascriptInterface(ColorBridge(layer), "RzkApp")
        // Скрипт страницы запускается в самом начале загрузки каждого документа
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            runCatching { WebViewCompat.addDocumentStartJavaScript(web, PAGE_JS, SCRIPT_ORIGINS) }
        }
        web.webViewClient = Client(layer)
        web.webChromeClient = chrome
        web.setDownloadListener { url, _, _, _, _ -> openExternal(url, forceBrowser = true) }
        web.setOnLongClickListener { onWebLongPress(layer) }
        if (!layer.isFeed) {
            web.setOnScrollChangeListener { _, _, y, _, oldY -> if (layer === article) onArticleScroll(y, oldY) }
        }
    }

    private fun setupFeedRefresh() {
        swipe.setColorSchemeColors(MaterialColors.getColor(root, com.google.android.material.R.attr.colorPrimary))
        swipe.setProgressBackgroundColorSchemeColor(
            MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurfaceContainerHigh)
        )
        swipe.setOnChildScrollUpCallback { _, _ -> feed.web.scrollY > 0 }
        swipe.setOnRefreshListener {
            feed.failedUrl = null
            feed.web.reload()
        }
    }

    // ───────────────────────────── WebView ─────────────────────────────

    private inner class Client(val layer: Layer) : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (!request.isForMainFrame) return false
            val uri = request.url
            val url = uri.toString()
            val scheme = uri.scheme?.lowercase()
            if (url == BLANK) return false
            // Предзагружаемые карты не трогаем: пусть сами проходят редиректы
            if (!layer.isFeed && layer !== article) return !isInternal(uri)
            if (scheme != "http" && scheme != "https") {
                openExternal(url); return true
            }
            if (!isInternal(uri)) {
                openExternal(url); return true
            }
            if (capturing || opening) return true            // двойной тап во время перехода
            layer.failedUrl = null
            if (request.isRedirect || pendingBack != null) return false
            if (isSameDocument(layer, url)) return false
            if (layer.isFeed && isArticle(url)) {
                openArticleFromFeed(url)
            } else {
                navigateForward(layer, url)
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            if (url == BLANK) return
            injectPageJs(view)
        }

        override fun onPageCommitVisible(view: WebView, url: String?) {
            if (url == BLANK) return
            injectPageJs(view)
            onContentVisible(layer, url)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (url == BLANK) return
            if (layer.isFeed) swipe.isRefreshing = false
            injectPageJs(view)
            onContentVisible(layer, url)
            if (layer === active) main.postDelayed({ sampleColors() }, 150)
            updateBackCallback()
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            layer.historyIndex = view.copyBackForwardList().currentIndex
            if (!layer.isFeed && layer === article && articleOpen && url != null && url != BLANK) {
                val id = articleId(url)
                val idx = articleList.indexOfFirst { articleId(it) == id }
                if (idx >= 0 && idx != articleIndex) {
                    articleIndex = idx
                    scheduleNeighbors(400)
                }
                refreshFab()
            }
            updateBackCallback()
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val desc = error.description?.toString().orEmpty()
            if (desc.contains("ERR_ABORTED")) return
            layer.failedUrl = request.url.toString()
            errorDetail = "${error.errorCode} · $desc"
            if (layer === active) showError()
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            destroyWebs()
            recreate()
            return true
        }
    }

    private inner class Chrome : WebChromeClient() {

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden(); return
            }
            customView = view
            customViewCallback = callback
            fullscreen.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fullscreen.alpha = 0f
            fullscreen.visibility = View.VISIBLE
            fullscreen.anim().alpha(1f).setDuration(ms(180)).setInterpolator(standard).start()
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            updateBackCallback()
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            customView = null
            fullscreen.removeView(v)
            fullscreen.visibility = View.GONE
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
            WindowInsetsControllerCompat(window, window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
            updateBackCallback()
        }
    }

    private fun onContentVisible(layer: Layer, url: String?) {
        if (!firstContentShown) {
            firstContentShown = true
            content.alpha = 0f
            content.translationY = dp(20f)
            content.anim().alpha(1f).translationY(0f).setDuration(ms(380))
                .setInterpolator(emphasizedDecel).start()
        }
        if (layer.clearHistoryOnCommit) {
            layer.clearHistoryOnCommit = false
            layer.web.clearHistory()
            layer.historyIndex = 0
            updateBackCallback()
        }
        layer.ready = true
        if (layer.awaitingFade && url != layer.fadeFromUrl && !layer.committed) {
            layer.committed = true
            if (layer.cleanedSeen) {
                fadeInContent(layer)
            } else {
                main.removeCallbacks(layer.gateTimeout)
                main.postDelayed(layer.gateTimeout, 900)   // не ждём дольше, даже если скрипт задержался
            }
        }
        if (!layer.isFeed && layer === article && articleOpen) scheduleNeighbors(300)
        if (layer.failedUrl != null && url == layer.failedUrl) {
            if (layer === active) showError()
        } else {
            layer.failedUrl = null
            if (layer === active) hideError()
        }
        if (pendingBack === layer && url != pendingBackFromUrl) finishGestureBack()
    }

    /**
     * Страницу прячем, пока она не загрузится И скрипт не уберёт шапку и нижние блоки —
     * так статья сразу появляется в чистом виде.
     */
    private fun gateFade(layer: Layer, fromUrl: String? = null) {
        layer.web.animate().cancel()
        layer.web.alpha = 0f
        layer.awaitingFade = true
        layer.fadeFromUrl = fromUrl
        layer.committed = false
        layer.cleanedSeen = false
        main.removeCallbacks(layer.gateTimeout)
        main.removeCallbacks(layer.fadeTimeout)
        main.postDelayed(layer.fadeTimeout, 8_000)
    }

    private fun onPageCleaned(layer: Layer) {
        if (!layer.awaitingFade) return
        layer.cleanedSeen = true
        if (layer.committed) fadeInContent(layer)
    }

    /** Новая страница готова — плавно проявляем её. */
    private fun fadeInContent(layer: Layer) {
        main.removeCallbacks(layer.fadeTimeout)
        main.removeCallbacks(layer.gateTimeout)
        layer.awaitingFade = false
        layer.fadeFromUrl = null
        if (layer.web.alpha >= 1f) return
        layer.web.anim().alpha(1f).setDuration(ms(160)).setInterpolator(standard).start()
    }

    private fun injectPageJs(web: WebView) {
        web.evaluateJavascript(PAGE_JS, null)
    }

    // ───────────────────────────── Открытие статьи: раскрытие из блока ленты ─────────────────────────────

    private fun openArticleFromFeed(url: String) {
        if (opening || articleOpen || closing) return
        opening = true
        // Снимок ленты — из него вырежем блок, из которого статья «вырастет»
        capture(feed.card) { shot ->
            feed.web.evaluateJavascript("$FEED_INFO_JS(${JSONObject.quote(url)})") { r ->
                opening = false
                val info = parseFeedInfo(r)
                articleList = info?.first ?: emptyList()
                val id = articleId(url)
                articleIndex = articleList.indexOfFirst { articleId(it) == id }
                val rect = info?.second
                val item = if (shot != null && rect != null) cropBitmap(shot, rect) else null
                openedItem = if (item != null) id to item else null
                showArticle(url, rect, item)
            }
        }
    }

    /** Список статей и прямоугольник блока (в пикселях карты ленты). */
    private fun parseFeedInfo(r: String?): Pair<List<String>, RectF?>? = runCatching {
        val o = JSONObject(JSONTokener(r).nextValue() as String)
        val arr = o.getJSONArray("list")
        val list = (0 until arr.length()).map { arr.getString(it) }
        val dpr = o.optDouble("dpr", 1.0).toFloat()
        val rr = o.optJSONArray("rect")
        val rect = if (rr != null && rr.length() == 4) {
            val x = rr.getDouble(0).toFloat() * dpr
            val y = rr.getDouble(1).toFloat() * dpr
            RectF(x, y, x + rr.getDouble(2).toFloat() * dpr, y + rr.getDouble(3).toFloat() * dpr)
        } else null
        list to rect
    }.getOrNull()

    private fun cropBitmap(src: Bitmap, r: RectF): Bitmap? = runCatching {
        val l = r.left.roundToInt().coerceIn(0, src.width - 1)
        val t = r.top.roundToInt().coerceIn(0, src.height - 1)
        val w = (r.right.roundToInt() - l).coerceIn(1, src.width - l)
        val h = (r.bottom.roundToInt() - t).coerceIn(1, src.height - t)
        Bitmap.createBitmap(src, l, t, w, h)
    }.getOrNull()

    private fun sameArticle(a: String?, b: String?): Boolean =
        a != null && b != null && articleId(a) == articleId(b)

    private fun showArticle(url: String, rect: RectF?, item: Bitmap?) {
        morphAnim?.end()
        // Если эта статья уже предзагружена в одной из карт — берём её, откроется мгновенно
        val cur = slots.firstOrNull { sameArticle(it.wantUrl, url) && sameArticle(it.web.url, url) }
            ?: slots.firstOrNull {
                !sameArticle(it.wantUrl, articleList.getOrNull(articleIndex + 1)) &&
                    !sameArticle(it.wantUrl, articleList.getOrNull(articleIndex - 1))
            }
            ?: slots[0]
        val others = slots.filter { it !== cur }.toMutableList()
        val wantNext = articleList.getOrNull(articleIndex + 1)
        val n = others.firstOrNull { sameArticle(it.wantUrl, wantNext) } ?: others.first()
        others.remove(n)
        article = cur
        nextSlot = n
        prevSlot = others.first()
        articleOpen = true
        slots.forEach { hideSlot(it); it.web.onResume() }

        val reused = cur.ready && sameArticle(cur.web.url, url)
        if (!reused) {
            loadInto(cur, url)
            gateFade(cur)
        } else {
            cur.web.alpha = 1f
            scheduleNeighbors(250)
        }

        val card = cur.card
        card.elevation = zTop
        card.visibility = View.VISIBLE
        underlayScrim.animate().cancel()
        underlayScrim.visibility = View.VISIBLE
        feed.card.pivotX = feed.card.width / 2f
        feed.card.pivotY = feed.card.height / 2f

        if (rect != null && card.width > 0) expandFrom(cur, rect, item) else riseIn(cur)

        refreshError()
        refreshFab()
        updateBackCallback()
        sampleColors()
        scheduleNeighbors(900)
    }

    /** Контур карты растёт от блока ленты до всего экрана, снимок блока растворяется. */
    private fun expandFrom(slot: Layer, from: RectF, item: Bitmap?) {
        val card = slot.card
        val full = RectF(0f, 0f, card.width.toFloat(), card.height.toFloat())
        val cur = RectF(from)
        val r0 = dp(18f)
        slot.outlineRect = cur
        slot.radius = r0
        card.clipToOutline = true
        card.invalidateOutline()
        setupMorph(item)
        val m = Matrix()
        morphAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms(340)
            interpolator = emphasizedDecel
            addUpdateListener {
                val t = it.animatedValue as Float
                lerpRect(from, full, t, cur)
                slot.radius = r0 * (1f - t)
                card.invalidateOutline()
                placeMorph(item, cur, m, 1f - (t / 0.3f).coerceIn(0f, 1f))
                underlayScrim.alpha = FEED_DIM * t
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    morphAnim = null
                    slot.outlineRect = null
                    slot.radius = 0f
                    card.clipToOutline = false
                    card.invalidateOutline()
                    hideMorph()
                }
            })
            start()
        }
    }

    /** Запасной вариант (ссылка извне): карта мягко поднимается и проявляется. */
    private fun riseIn(slot: Layer) {
        val card = slot.card
        card.alpha = 0f
        card.translationY = dp(36f)
        card.scaleX = 0.97f
        card.scaleY = 0.97f
        card.anim().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(ms(280))
            .setInterpolator(emphasizedDecel).start()
        underlayScrim.anim().alpha(FEED_DIM).setDuration(ms(280)).setInterpolator(emphasizedDecel).start()
    }

    private fun closeArticle(fromGesture: Boolean = false) {
        if (!articleOpen) return
        morphAnim?.end()
        val cur = article
        articleOpen = false
        closing = true
        main.removeCallbacks(neighborsTask)
        slots.forEach { it.web.evaluateJavascript(PAUSE_MEDIA_JS, null) }
        refreshError()
        refreshFab()
        updateBackCallback()

        if (fromGesture) {
            val card = cur.card
            card.anim()
                .alpha(0f).scaleX(0.84f).scaleY(0.84f)
                .translationX(card.translationX + gestureDir * dp(40f))
                .setDuration(ms(180)).setInterpolator(emphasizedAccel)
                .withEndAction { afterClose(cur) }.start()
            restoreFeed(ms(220))
            main.postDelayed({ sampleColors() }, 60)
            return
        }

        // Сворачиваем статью обратно в её блок, если он виден в ленте
        val url = cur.web.url ?: cur.wantUrl ?: ""
        feed.web.evaluateJavascript("$FEED_INFO_JS(${JSONObject.quote(url)})") { r ->
            val rect = parseFeedInfo(r)?.second
            val item = openedItem?.takeIf { it.first == articleId(url) }?.second
            if (rect != null && cur.card.width > 0) collapseTo(cur, rect, item) else fallAway(cur)
            sampleColors()
        }
    }

    private fun collapseTo(slot: Layer, to: RectF, item: Bitmap?) {
        val card = slot.card
        val full = RectF(0f, 0f, card.width.toFloat(), card.height.toFloat())
        val cur = RectF(full)
        val r1 = dp(18f)
        card.animate().cancel()
        card.alpha = 1f; card.scaleX = 1f; card.scaleY = 1f
        card.translationX = 0f; card.translationY = 0f; card.rotation = 0f
        slot.outlineRect = cur
        card.clipToOutline = true
        setupMorph(item)
        morph.alpha = 0f
        val m = Matrix()
        val d0 = underlayScrim.alpha
        morphAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms(300)
            interpolator = standard
            addUpdateListener {
                val t = it.animatedValue as Float
                lerpRect(full, to, t, cur)
                slot.radius = r1 * t
                card.invalidateOutline()
                slot.web.alpha = 1f - (t / 0.35f).coerceIn(0f, 1f)
                placeMorph(item, cur, m, ((t - 0.3f) / 0.45f).coerceIn(0f, 1f))
                underlayScrim.alpha = d0 * (1f - t)
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    morphAnim = null
                    hideMorph()
                    afterClose(slot)
                }
            })
            start()
        }
    }

    /** Блока не видно (например, пролистали колодой далеко) — карта просто уходит вниз и тает. */
    private fun fallAway(slot: Layer) {
        slot.card.anim().alpha(0f).translationY(dp(32f)).scaleX(0.96f).scaleY(0.96f).setDuration(ms(220))
            .setInterpolator(emphasizedAccel).withEndAction { afterClose(slot) }.start()
        restoreFeed(ms(260))
    }

    private fun restoreFeed(dur: Long) {
        underlayScrim.anim().alpha(0f).setDuration(dur).setInterpolator(standard)
            .withEndAction { if (!articleOpen) underlayScrim.visibility = View.GONE }.start()
    }

    private fun afterClose(slot: Layer) {
        closing = false
        updateBackCallback()
        if (articleOpen) return
        slots.forEach { hideSlot(it); it.web.onPause() }
        slot.web.alpha = 1f
        feed.card.scaleX = 1f
        feed.card.scaleY = 1f
        underlayScrim.alpha = 0f
        underlayScrim.visibility = View.GONE
        hideUnderlay()
    }

    private fun setupMorph(item: Bitmap?) {
        if (item == null) {
            hideMorph(); return
        }
        morph.setImageBitmap(item)
        morph.alpha = 1f
        morph.visibility = View.VISIBLE
    }

    /** Снимок блока растягивается по ширине текущего контура. */
    private fun placeMorph(item: Bitmap?, r: RectF, m: Matrix, alpha: Float) {
        if (item == null || morph.visibility != View.VISIBLE) return
        val s = r.width() / item.width
        m.setScale(s, s)
        m.postTranslate(r.left, r.top)
        morph.imageMatrix = m
        morph.alpha = alpha
    }

    private fun hideMorph() {
        morph.visibility = View.GONE
        morph.setImageDrawable(null)
    }

    private fun lerpRect(a: RectF, b: RectF, t: Float, out: RectF) {
        out.set(
            a.left + (b.left - a.left) * t,
            a.top + (b.top - a.top) * t,
            a.right + (b.right - a.right) * t,
            a.bottom + (b.bottom - a.bottom) * t
        )
    }

    private fun hideSlot(s: Layer) {
        val c = s.card
        c.animate().cancel()
        c.visibility = View.INVISIBLE
        c.alpha = 1f; c.scaleX = 1f; c.scaleY = 1f
        c.translationX = 0f; c.translationY = 0f; c.translationZ = 0f; c.rotation = 0f
        c.elevation = 0f
        s.outlineRect = null
        s.radius = 0f
        c.clipToOutline = false
        c.invalidateOutline()
    }

    private fun loadInto(slot: Layer, url: String?) {
        slot.wantUrl = url
        slot.ready = false
        slot.failedUrl = null
        slot.snapshots.clear()
        if (url == null) {
            slot.clearHistoryOnCommit = false
            slot.web.loadUrl(BLANK)
        } else {
            slot.clearHistoryOnCommit = true    // у карты своя история: «назад» ведёт в ленту
            slot.web.loadUrl(url)
        }
    }

    // ───────────────────────────── Колода: предзагрузка и свайпы ─────────────────────────────

    private fun scheduleNeighbors(delay: Long) {
        main.removeCallbacks(neighborsTask)
        main.postDelayed(neighborsTask, delay)
    }

    /** Следующая и предыдущая статьи грузятся заранее в скрытых картах. */
    private fun ensureNeighbors() {
        if (!articleOpen || articleIndex < 0) return
        val wantNext = articleList.getOrNull(articleIndex + 1)
        val wantPrev = articleList.getOrNull(articleIndex - 1)
        if (needsLoad(nextSlot, wantNext)) loadInto(nextSlot, wantNext)
        if (needsLoad(prevSlot, wantPrev)) loadInto(prevSlot, wantPrev)
    }

    private fun needsLoad(slot: Layer, want: String?): Boolean =
        if (want == null) slot.wantUrl != null else !sameArticle(slot.wantUrl, want)

    private fun canSwipeNow(): Boolean =
        articleOpen && !deckAnimating && morphAnim == null && !transitionBusy && !capturing &&
            pendingBack == null && gesture == Gesture.NONE && customView == null &&
            articleIndex >= 0 && articleList.size > 1

    private fun hasTarget(delta: Int): Boolean = (articleIndex + delta) in articleList.indices

    /**
     * Листание как в многозадачности: карточки уменьшаются и едут вбок рядом друг с другом,
     * выбранная доезжает до центра и вырастает на весь экран.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDeckSwipes(slot: Layer) {
        val cfg = ViewConfiguration.get(this)
        val slop = cfg.scaledTouchSlop.toFloat()
        val minFling = cfg.scaledMinimumFlingVelocity * 4f
        slot.web.setOnTouchListener { v, ev ->
            if (slot !== article) return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragX0 = ev.rawX      // экранные координаты: карточка движется под пальцем
                    dragY0 = ev.rawY
                    dragState = DRAG_UNDECIDED
                    horizontalBlocked = false
                    velocity?.recycle()
                    velocity = VelocityTracker.obtain().also { trackRaw(it, ev) }
                    val edge = dp(28f)   // у краёв — системный жест «назад»
                    if (!canSwipeNow() || ev.x < edge || ev.x > slot.card.width - edge) {
                        dragState = DRAG_REJECTED
                    } else {
                        probeHorizontalScroll(slot, ev.x, ev.y)
                    }
                    false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (dragState == DRAG_ACTIVE) springBack()
                    dragState = DRAG_REJECTED
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    velocity?.let { trackRaw(it, ev) }
                    val dx = ev.rawX - dragX0
                    val dy = ev.rawY - dragY0
                    if (dragState == DRAG_UNDECIDED) {
                        when {
                            horizontalBlocked || !canSwipeNow() -> dragState = DRAG_REJECTED
                            abs(dy) > slop && abs(dy) >= abs(dx) -> dragState = DRAG_REJECTED
                            abs(dx) > slop * 1.5f && abs(dx) > abs(dy) * 1.6f -> startDrag(v, ev)
                        }
                    }
                    if (dragState == DRAG_ACTIVE) {
                        applyDrag(dx); true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wasDragging = dragState == DRAG_ACTIVE
                    if (wasDragging) {
                        velocity?.let { trackRaw(it, ev) }
                        velocity?.computeCurrentVelocity(1000)
                        val vx = velocity?.xVelocity ?: 0f
                        finishDrag(ev.rawX - dragX0, vx, ev.actionMasked == MotionEvent.ACTION_CANCEL, minFling)
                    }
                    velocity?.recycle()
                    velocity = null
                    dragState = DRAG_UNDECIDED
                    wasDragging
                }
                else -> dragState == DRAG_ACTIVE
            }
        }
    }

    /** Скорость считаем тоже в экранных координатах. */
    private fun trackRaw(vt: VelocityTracker, ev: MotionEvent) {
        val e = MotionEvent.obtain(ev)
        e.setLocation(ev.rawX, ev.rawY)
        vt.addMovement(e)
        e.recycle()
    }

    private fun probeHorizontalScroll(slot: Layer, x: Float, y: Float) {
        slot.web.evaluateJavascript("$HSCROLL_JS(${x.roundToInt()},${y.roundToInt()})") { r ->
            if (r == "true") horizontalBlocked = true
        }
    }

    private fun startDrag(v: View, ev: MotionEvent) {
        dragState = DRAG_ACTIVE
        // Забираем касание у страницы, чтобы она не прокручивалась вместе с пальцем
        val cancel = MotionEvent.obtain(ev)
        cancel.action = MotionEvent.ACTION_CANCEL
        v.onTouchEvent(cancel)
        cancel.recycle()
        v.parent?.requestDisallowInterceptTouchEvent(true)
        pagerAnim?.cancel()
        pagerAnim = null
        for (s in slots) {
            s.card.animate().cancel()
            s.card.pivotX = s.card.width / 2f
            s.card.pivotY = s.card.height / 2f
        }
        // Фон «многозадачности» под уменьшенными карточками
        underlay.setImageDrawable(null)
        underlay.setBackgroundColor(ColorUtils.blendARGB(bottomColor, Color.BLACK, 0.45f))
        underlay.alpha = 0f
        underlay.visibility = View.VISIBLE
        article.web.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    /** Масштаб карточек в зависимости от того, насколько далеко увели палец. */
    private fun dragScale(dx: Float, w: Float): Float =
        1f - (1f - PAGER_MIN_SCALE) * min(1f, abs(dx) / (w * 0.22f))

    private fun applyDrag(dx: Float) {
        val w = article.card.width.toFloat()
        if (w <= 0f) return
        val delta = if (dx < 0) 1 else -1
        val eff = if (hasTarget(delta)) dx else dx * 0.25f     // у крайней статьи — упругое сопротивление
        val s = dragScale(eff, w)
        pagerScale = s
        pagerOffset = eff / pagerStep(s)
        layoutPager()
    }

    private fun pagerStep(s: Float): Float = article.card.width * s + dp(PAGER_GAP_DP)

    /**
     * Карточки стоят в ряд с зазором: предыдущая слева, текущая в центре, следующая справа.
     * pagerOffset — сдвиг ряда в «карточках», pagerScale — общий масштаб.
     */
    private fun layoutPager() {
        val s = pagerScale
        val step = pagerStep(s)
        val k = ((1f - s) / (1f - PAGER_MIN_SCALE)).coerceIn(0f, 1f)
        val radius = dp(24f) * k
        placeCard(article, 0, step, s, radius)
        if (hasTarget(1)) placeCard(nextSlot, 1, step, s, radius) else hideSlot(nextSlot)
        if (hasTarget(-1)) placeCard(prevSlot, -1, step, s, radius) else hideSlot(prevSlot)
        underlay.alpha = k
    }

    private fun placeCard(l: Layer, pos: Int, step: Float, s: Float, radius: Float) {
        val c = l.card
        c.visibility = View.VISIBLE
        c.elevation = zTop
        c.rotation = 0f
        c.alpha = 1f
        c.scaleX = s
        c.scaleY = s
        c.translationX = (pos + pagerOffset) * step
        c.translationY = 0f
        l.web.alpha = 1f
        l.radius = if (s > 0f) radius / s else radius    // контур задаётся в немасштабированных координатах
        c.clipToOutline = radius > 0.5f
        c.invalidateOutline()
    }

    private fun finishDrag(dx: Float, vx: Float, cancelled: Boolean, minFling: Float) {
        val delta = if (dx < 0) 1 else -1
        val far = abs(dx) > article.card.width * 0.3f
        val flung = abs(vx) > minFling && (vx < 0) == (dx < 0)
        val target = if (!cancelled && hasTarget(delta) && (far || flung)) -delta.toFloat() else 0f
        settlePager(target)
    }

    private fun springBack() = settlePager(0f)

    /**
     * Ряд доезжает до выбранной карточки, и она одновременно вырастает на весь экран.
     * target: −1 — следующая статья, +1 — предыдущая, 0 — остаёмся.
     */
    private fun settlePager(target: Float) {
        pagerAnim?.cancel()
        val p0 = pagerOffset
        val s0 = pagerScale
        deckAnimating = true
        if (target != 0f) article.web.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        pagerAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms(340)
            interpolator = emphasizedDecel
            addUpdateListener {
                val t = it.animatedValue as Float
                pagerOffset = p0 + (target - p0) * t
                pagerScale = s0 + (1f - s0) * t
                layoutPager()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelledHere = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelledHere = true
                    deckAnimating = false
                }

                override fun onAnimationEnd(animation: Animator) {
                    pagerAnim = null
                    if (cancelledHere) return
                    pagerOffset = 0f
                    pagerScale = 1f
                    when {
                        target < 0f -> swapForward()
                        target > 0f -> swapBack()
                        else -> {
                            hideSlot(nextSlot)
                            hideSlot(prevSlot)
                            resetCurrentCard()
                            hideUnderlay()
                            underlay.alpha = 1f
                            deckAnimating = false
                        }
                    }
                }
            })
            start()
        }
    }

    private fun resetCurrentCard() {
        val c = article.card
        c.animate().cancel()
        c.visibility = View.VISIBLE
        c.elevation = zTop
        c.alpha = 1f; c.scaleX = 1f; c.scaleY = 1f
        c.translationX = 0f; c.translationY = 0f; c.rotation = 0f
        article.radius = 0f
        c.clipToOutline = false
        c.invalidateOutline()
        article.web.alpha = 1f
    }

    private fun swapForward() {
        val old = article
        val n = nextSlot
        val rec = prevSlot
        article = n
        prevSlot = old
        nextSlot = rec
        articleIndex++
        afterSwap(old, rec)
    }

    private fun swapBack() {
        val old = article
        val pv = prevSlot
        val rec = nextSlot
        article = pv
        nextSlot = old
        prevSlot = rec
        articleIndex--
        afterSwap(old, rec)
    }

    private fun afterSwap(old: Layer, rec: Layer) {
        hideSlot(old)
        hideSlot(rec)
        resetCurrentCard()
        // Соседняя статья могла не успеть загрузиться — догружаем её прямо сейчас
        val want = articleList.getOrNull(articleIndex)
        if (want != null && (!sameArticle(article.wantUrl, want) || article.web.url == BLANK || article.web.url == null)) {
            loadInto(article, want)
            gateFade(article)
        }
        old.web.evaluateJavascript(PAUSE_MEDIA_JS, null)
        hideUnderlay()
        underlay.alpha = 1f
        deckAnimating = false
        refreshError()
        refreshFab()
        updateBackCallback()
        sampleColors()
        scheduleNeighbors(if (article.ready) 150 else 600)
    }

    // ───────────────────────────── Переходы по ссылкам внутри экрана ─────────────────────────────

    private fun navigateForward(layer: Layer, url: String) {
        if (capturing) return
        layer.failedUrl = null
        capture(layer.card) { bmp ->
            if (bmp != null) {
                cacheSnapshot(layer, layer.historyIndex, bmp)
                slideTransition(layer, Dir.FORWARD, bmp)
            }
            layer.web.loadUrl(url)
        }
    }

    private fun goBackAnimated(layer: Layer) {
        if (capturing || !layer.web.canGoBack()) return
        layer.failedUrl = null
        capture(layer.card) { bmp ->
            if (bmp != null) slideTransition(layer, Dir.BACK, bmp)
            layer.web.goBack()
        }
    }

    /**
     * Shared axis X, сразу, без ожидания загрузки: старая страница уезжает и тает,
     * новая въезжает навстречу и проявляется, как только будет готова.
     */
    private fun slideTransition(layer: Layer, dir: Dir, bmp: Bitmap) {
        val shift = dp(SHIFT_DP)
        val sign = if (dir == Dir.FORWARD) 1f else -1f
        overlay.animate().cancel()
        overlay.setImageBitmap(bmp)
        overlay.alpha = 1f
        overlay.translationX = 0f
        overlay.visibility = View.VISIBLE

        val card = layer.card
        card.animate().cancel()
        card.translationX = shift * sign
        gateFade(layer, layer.web.url)

        overlay.anim().alpha(0f).translationX(-shift * sign).setDuration(ms(200)).setInterpolator(emphasizedDecel)
            .withEndAction {
                overlay.visibility = View.GONE
                overlay.setImageDrawable(null)
                overlay.translationX = 0f
            }.start()
        card.anim().translationX(0f).setDuration(ms(260)).setInterpolator(emphasizedDecel).start()

        transitionBusy = true
        main.removeCallbacks(transitionDone)
        main.postDelayed(transitionDone, ms(260))
        updateBackCallback()
    }

    private fun capture(card: View, done: (Bitmap?) -> Unit) {
        val w = card.width
        val h = card.height
        if (w <= 0 || h <= 0 || card.visibility != View.VISIBLE) {
            done(null); return
        }
        val bmp = try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            done(null); return
        }
        capturing = true
        val finish: (Bitmap?) -> Unit = { b ->
            capturing = false
            done(b)
        }
        val loc = IntArray(2)
        card.getLocationInWindow(loc)
        try {
            PixelCopy.request(window, Rect(loc[0], loc[1], loc[0] + w, loc[1] + h), bmp, { result ->
                finish(if (result == PixelCopy.SUCCESS) bmp else drawFallback(card))
            }, main)
        } catch (e: Exception) {
            finish(drawFallback(card))
        }
    }

    private fun drawFallback(card: View): Bitmap? = try {
        card.drawToBitmap()
    } catch (e: Exception) {
        null
    }

    private fun cacheSnapshot(layer: Layer, index: Int, bmp: Bitmap) {
        val scaled = try {
            Bitmap.createScaledBitmap(bmp, max(1, bmp.width / 2), max(1, bmp.height / 2), true)
        } catch (e: OutOfMemoryError) {
            return
        }
        val map = layer.snapshots
        map.keys.filter { it >= index }.forEach { map.remove(it) }
        map[index] = scaled
        while (map.size > MAX_SNAPSHOTS) map.remove(map.keys.min())
    }

    // ───────────────────────────── «Назад» и жест с предпросмотром ─────────────────────────────

    private fun onBack() {
        when {
            customView != null -> chrome.onHideCustomView()
            gesture != Gesture.NONE -> commitBackGesture()
            pendingBack != null -> finishGestureBack()
            deckAnimating || closing -> Unit
            articleOpen -> if (article.web.canGoBack()) goBackAnimated(article) else closeArticle()
            feed.web.canGoBack() -> goBackAnimated(feed)
            else -> {
                backCallback.isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun startBackGesture(e: BackEventCompat) {
        gesture = Gesture.NONE
        gestureLayer = null
        if (customView != null || transitionBusy || pendingBack != null || capturing || deckAnimating || dragState == DRAG_ACTIVE) return
        morphAnim?.end()
        val layer = active
        when {
            articleOpen && !article.web.canGoBack() -> {
                gesture = Gesture.CLOSE_ARTICLE
                underlay.visibility = View.GONE
                underlayScrim.animate().cancel()
                underlayScrim.visibility = View.VISIBLE
                underlayScrim.alpha = FEED_DIM
            }
            layer.web.canGoBack() -> {
                gesture = Gesture.IN_LAYER
                underlay.setBackgroundColor(bottomColor)
                underlay.setImageBitmap(layer.snapshots[layer.historyIndex - 1])
                underlay.visibility = View.VISIBLE
                underlayScrim.animate().cancel()
                underlayScrim.alpha = GESTURE_DIM
                underlayScrim.visibility = View.VISIBLE
            }
            else -> return
        }
        gestureLayer = layer
        gestureDir = if (e.swipeEdge == BackEventCompat.EDGE_LEFT) 1f else -1f
        gestureStartY = e.touchY
        val card = layer.card
        card.animate().cancel()
        card.pivotX = card.width / 2f
        card.pivotY = card.height / 2f
        card.translationZ = 1f      // поверх снимка и затемнения
        card.clipToOutline = true
    }

    private fun progressBackGesture(e: BackEventCompat) {
        val layer = gestureLayer ?: return
        if (gesture == Gesture.NONE) return
        val card = layer.card
        val p = e.progress
        val s = 1f - 0.1f * p
        card.scaleX = s
        card.scaleY = s
        card.translationX = gestureDir * dp(24f) * p
        val dy = (e.touchY - gestureStartY) * 0.1f
        card.translationY = dy.coerceIn(-dp(24f), dp(24f)) * p
        card.translationZ = 1f + dp(8f) * p
        setRadius(layer, dp(28f) * min(1f, p * 3f))
        if (gesture == Gesture.CLOSE_ARTICLE) {
            underlayScrim.alpha = FEED_DIM * (1f - p)
        } else {
            underlayScrim.alpha = GESTURE_DIM * (1f - p)
        }
    }

    private fun cancelBackGesture() {
        val layer = gestureLayer ?: return
        val mode = gesture
        if (mode == Gesture.NONE) return
        gesture = Gesture.NONE
        gestureLayer = null
        val card = layer.card
        val r0 = layer.radius
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = ms(220)
            interpolator = standard
            addUpdateListener { setRadius(layer, r0 * (it.animatedValue as Float)) }
            start()
        }
        if (mode == Gesture.CLOSE_ARTICLE) {
            underlayScrim.anim().alpha(FEED_DIM).setDuration(ms(220)).setInterpolator(standard).start()
        } else {
            underlayScrim.anim().alpha(GESTURE_DIM).setDuration(ms(220)).setInterpolator(standard).start()
        }
        card.anim().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).translationZ(0f)
            .setDuration(ms(220)).setInterpolator(standard)
            .withEndAction {
                resetGestureCard(layer)
                if (mode == Gesture.IN_LAYER) {
                    hideUnderlay(); restoreScrim()
                }
            }.start()
    }

    private fun commitBackGesture() {
        val layer = gestureLayer ?: return
        val mode = gesture
        gesture = Gesture.NONE
        gestureLayer = null
        if (mode == Gesture.CLOSE_ARTICLE) {
            closeArticle(fromGesture = true)
            return
        }
        pendingBack = layer
        pendingBackFromUrl = layer.web.url
        layer.failedUrl = null
        main.removeCallbacks(gestureTimeout)
        main.postDelayed(gestureTimeout, 8_000)

        val card = layer.card
        underlayScrim.anim().alpha(0f).setDuration(ms(180)).setInterpolator(standard).start()
        card.anim()
            .alpha(0f)
            .scaleX(0.86f).scaleY(0.86f)
            .translationX(card.translationX + gestureDir * dp(40f))
            .setDuration(ms(180))
            .setInterpolator(emphasizedAccel)
            .withEndAction {
                resetGestureCard(layer)
                card.alpha = 0f
                layer.web.goBack()
            }.start()
        updateBackCallback()
    }

    /** Предыдущая страница загрузилась — проявляем её поверх снимка. */
    private fun finishGestureBack() {
        val layer = pendingBack ?: return
        pendingBack = null
        pendingBackFromUrl = null
        main.removeCallbacks(gestureTimeout)
        layer.card.anim().alpha(1f).setDuration(ms(180)).setInterpolator(standard)
            .withEndAction { hideUnderlay(); restoreScrim() }.start()
        updateBackCallback()
    }

    private fun setRadius(layer: Layer, r: Float) {
        layer.radius = r
        layer.card.invalidateOutline()
    }

    private fun resetGestureCard(layer: Layer) {
        val card = layer.card
        card.alpha = 1f
        card.scaleX = 1f
        card.scaleY = 1f
        card.translationX = 0f
        card.translationY = 0f
        card.translationZ = 0f
        setRadius(layer, 0f)
        card.clipToOutline = false
    }

    private fun hideUnderlay() {
        underlay.visibility = View.GONE
        underlay.setImageDrawable(null)
    }

    /** Затемнение нужно только под открытой статьёй. */
    private fun restoreScrim() {
        if (articleOpen) {
            underlayScrim.visibility = View.VISIBLE
            underlayScrim.alpha = FEED_DIM
        } else {
            underlayScrim.visibility = View.GONE
            underlayScrim.alpha = 0f
        }
    }

    private fun updateBackCallback() {
        backCallback.isEnabled = customView != null || transitionBusy || pendingBack != null ||
            articleOpen || closing || (websAlive && feed.web.canGoBack())
    }

    // ───────────────────────────── Ошибки и цвета ─────────────────────────────

    private fun refreshError() {
        val l = active
        if (l.failedUrl != null && l.web.url == l.failedUrl) showError() else hideError()
    }

    private fun showError() {
        errorCode.text = errorDetail
        errorCode.visibility = if (errorDetail.isBlank()) View.GONE else View.VISIBLE
        if (pendingBack != null) finishGestureBack()
        swipe.isRefreshing = false
        fadeInContent(active)
        if (errorView.visibility == View.VISIBLE && errorView.alpha >= 1f) return
        errorView.alpha = 0f
        errorView.scaleX = 0.96f
        errorView.scaleY = 0.96f
        errorView.visibility = View.VISIBLE
        errorView.anim().alpha(1f).scaleX(1f).scaleY(1f).setDuration(ms(260))
            .setInterpolator(emphasizedDecel).start()
    }

    private fun hideError() {
        if (errorView.visibility != View.VISIBLE) return
        errorView.anim().alpha(0f).setDuration(ms(180)).setInterpolator(standard)
            .withEndAction { errorView.visibility = View.GONE }.start()
    }

    /**
     * Страница сама сообщает свои цвета (при загрузке, прокрутке и смене темы на сайте) —
     * подложки статус-бара и навигации перекрашиваются сразу.
     */
    private inner class ColorBridge(val layer: Layer) {
        @JavascriptInterface
        fun colors(raw: String) {
            main.post { onPageColors(layer, raw) }
        }

        @JavascriptInterface
        fun cleaned() {
            main.post { onPageCleaned(layer) }
        }
    }

    private fun onPageColors(layer: Layer, raw: String) {
        val parts = raw.split('|').map { parseCssColor(it) }
        val page = parts.getOrNull(2) ?: return
        val c = Triple(parts.getOrNull(0) ?: page, parts.getOrNull(1) ?: page, page)
        layer.colors = c
        if (layer === active) applyColors(c.first, c.second, c.third)
    }

    /** Применить уже известные цвета активного экрана и попросить страницу пересчитать их. */
    private fun sampleColors() {
        if (!websAlive) return
        val layer = active
        layer.colors?.let { applyColors(it.first, it.second, it.third) }
        layer.web.evaluateJavascript("window.__rzkReport&&window.__rzkReport()", null)
    }

    private fun parseCssColor(c: String): Int? {
        val n = Regex("[\\d.]+").findAll(c).map { it.value.toFloatOrNull() ?: 0f }.toList()
        if (n.size < 3) return null
        if (n.size >= 4 && n[3] < 0.5f) return null
        return Color.rgb(n[0].toInt().coerceIn(0, 255), n[1].toInt().coerceIn(0, 255), n[2].toInt().coerceIn(0, 255))
    }

    private fun applyColors(top: Int, bottom: Int, page: Int) {
        if (top != topColor) animateBg(statusScrim, topColor, top)
        if (bottom != bottomColor) animateBg(navScrim, bottomColor, bottom)
        topColor = top
        bottomColor = bottom
        root.setBackgroundColor(page)
        for (l in allLayers) {
            l.card.setBackgroundColor(page)
            l.web.setBackgroundColor(page)
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = ColorUtils.calculateLuminance(top) > 0.5
            isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(bottom) > 0.5
        }
    }

    private fun animateBg(v: View, from: Int, to: Int) {
        ValueAnimator.ofArgb(from, to).apply {
            duration = ms(200)
            interpolator = standard
            addUpdateListener { v.setBackgroundColor(it.animatedValue as Int) }
            start()
        }
    }

    // ───────────────────────────── Кнопка «Поделиться» ─────────────────────────────

    private fun isArticle(url: String?): Boolean {
        val path = url?.let { Uri.parse(it).path } ?: return false
        return ARTICLE.containsMatchIn(path)
    }

    private fun articleId(url: String): String =
        ARTICLE_ID.find(Uri.parse(url).path ?: "")?.groupValues?.get(1) ?: url

    private fun refreshFab() {
        if (articleOpen && isArticle(article.web.url ?: article.wantUrl)) fab.show() else fab.hide()
    }

    private fun onArticleScroll(y: Int, oldY: Int) {
        if (!articleOpen) return
        val dy = y - oldY
        if (abs(dy) < 4) return
        if (dy > 0) fab.hide() else fab.show()
    }

    // ───────────────────────────── Долгое нажатие на ссылку ─────────────────────────────

    private fun onWebLongPress(layer: Layer): Boolean {
        if (dragState == DRAG_ACTIVE) return true
        val web = layer.web
        val hit = web.hitTestResult
        return when (hit.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                val url = hit.extra ?: return false
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showLinkSheet(url, layer)
                true
            }
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                hrefFrom = layer
                web.requestFocusNodeHref(hrefHandler.obtainMessage())
                true
            }
            else -> false
        }
    }

    private fun showLinkSheet(url: String, from: Layer) {
        val dialog = BottomSheetDialog(this)
        val v = LayoutInflater.from(dialog.context).inflate(R.layout.sheet_link, null)
        v.findViewById<TextView>(R.id.linkTitle).text = prettyUrl(url)
        fun action(id: Int, block: () -> Unit) {
            v.findViewById<View>(id).setOnClickListener {
                dialog.dismiss()
                block()
            }
        }
        action(R.id.actOpen) {
            when {
                !isInternal(Uri.parse(url)) -> openExternal(url)
                from.isFeed && isArticle(url) -> openArticleFromFeed(url)
                else -> navigateForward(from, url)
            }
        }
        action(R.id.actShare) { share(url, null) }
        action(R.id.actCopy) { copy(url) }
        action(R.id.actBrowser) { openExternal(url, forceBrowser = true) }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun prettyUrl(url: String): String {
        val u = Uri.parse(url)
        val host = u.host?.removePrefix("www.") ?: return url
        val path = Uri.decode(u.path ?: "").trimEnd('/')
        return host + path
    }

    // ───────────────────────────── Внешние ссылки, «поделиться», буфер ─────────────────────────────

    private fun isInternal(uri: Uri): Boolean {
        val h = uri.host?.lowercase() ?: return false
        return h == "rozetked.me" || h.endsWith(".rozetked.me")
    }

    private fun isSameDocument(layer: Layer, url: String): Boolean {
        val cur = layer.web.url ?: return false
        return url.contains('#') && url.substringBefore('#') == cur.substringBefore('#')
    }

    private fun openExternal(url: String, forceBrowser: Boolean = false) {
        val intent: Intent = try {
            if (url.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
        } catch (e: Exception) {
            toast(getString(R.string.no_app)); return
        }
        if (forceBrowser || isInternal(Uri.parse(url))) defaultBrowserPackage()?.let { intent.setPackage(it) }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val fallback = intent.getStringExtra("browser_fallback_url")
            if (fallback != null) {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback))) }
                    .onFailure { toast(getString(R.string.no_app)) }
            } else {
                toast(getString(R.string.no_app))
            }
        }
    }

    /** Браузер по умолчанию — чтобы ссылки rozetked.me «в браузере» не возвращались в это приложение. */
    private fun defaultBrowserPackage(): String? {
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
            .addCategory(Intent.CATEGORY_BROWSABLE)
        val pkg = packageManager.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName ?: return null
        return pkg.takeIf { it != "android" && it != packageName }
    }

    private fun share(url: String, title: String?) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
            if (!title.isNullOrBlank()) {
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TITLE, title)
            }
        }
        startActivity(Intent.createChooser(send, null))
    }

    private fun copy(url: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("link", url))
        if (Build.VERSION.SDK_INT < 33) toast(getString(R.string.copied))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────────────────────── Мелочи ─────────────────────────────

    /** Все анимации проходят через этот множитель — так их общую скорость легко подстроить. */
    private fun ms(v: Int): Long = (v * ANIM_SLOWDOWN).toLong()

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Аниматор «с чистого листа»: сбрасывает задержку и слушатели от прошлых анимаций. */
    private fun View.anim(): ViewPropertyAnimator {
        animate().cancel()
        return animate().setStartDelay(0).setUpdateListener(null).setListener(null)
    }
}
